'use strict';

const express = require('express');
const { db } = require('./db');

const router = express.Router();

/* ------------------------------------------------------------- student view */

const studentSummary = db.prepare(`
  SELECT
    (SELECT COUNT(*) FROM enrollments e WHERE e.student_id = @sid) AS courses,
    (SELECT COALESCE(SUM(c.credits), 0) FROM courses c
       JOIN enrollments e ON e.course_id = c.id AND e.student_id = @sid) AS credits,
    (SELECT COUNT(*) FROM topics t JOIN enrollments e ON e.course_id = t.course_id AND e.student_id = @sid) AS topics,
    (SELECT COUNT(*) FROM topic_progress p JOIN topics t ON t.id = p.topic_id
       JOIN enrollments e ON e.course_id = t.course_id AND e.student_id = @sid
       WHERE p.student_id = @sid AND p.status = 'completed') AS topics_completed,
    (SELECT COUNT(*) FROM topic_progress p JOIN topics t ON t.id = p.topic_id
       JOIN enrollments e ON e.course_id = t.course_id AND e.student_id = @sid
       WHERE p.student_id = @sid AND p.status = 'in_progress') AS topics_in_progress,
    (SELECT COALESCE(SUM(t.est_hours), 0) FROM topics t
       JOIN enrollments e ON e.course_id = t.course_id AND e.student_id = @sid) AS study_hours,
    (SELECT COUNT(*) FROM assignments a
       JOIN enrollments e ON e.course_id = a.course_id AND e.student_id = @sid
       LEFT JOIN assignment_progress ap ON ap.assignment_id = a.id AND ap.student_id = @sid
       WHERE COALESCE(ap.status, 'todo') IN ('todo','in_progress','late')) AS open_assignments,
    (SELECT COUNT(*) FROM assignments a
       JOIN enrollments e ON e.course_id = a.course_id AND e.student_id = @sid
       LEFT JOIN assignment_progress ap ON ap.assignment_id = a.id AND ap.student_id = @sid
       WHERE COALESCE(ap.status, 'todo') IN ('todo','in_progress','late')
         AND a.due_date < date('now')) AS overdue_assignments,
    (SELECT COUNT(*) FROM assignments a
       JOIN enrollments e ON e.course_id = a.course_id AND e.student_id = @sid
       LEFT JOIN assignment_progress ap ON ap.assignment_id = a.id AND ap.student_id = @sid
       WHERE COALESCE(ap.status, 'todo') IN ('todo','in_progress')
         AND a.due_date BETWEEN date('now') AND date('now', '+7 days')) AS due_this_week,
    (SELECT COUNT(*) FROM assignment_progress ap JOIN assignments a ON a.id = ap.assignment_id
       JOIN enrollments e ON e.course_id = a.course_id AND e.student_id = @sid
       WHERE ap.student_id = @sid AND ap.status = 'submitted') AS submitted,
    (SELECT COUNT(*) FROM assignment_progress ap JOIN assignments a ON a.id = ap.assignment_id
       JOIN enrollments e ON e.course_id = a.course_id AND e.student_id = @sid
       WHERE ap.student_id = @sid AND ap.status = 'graded') AS graded,
    (SELECT ROUND(AVG(ap.score * 100.0 / a.max_marks), 1)
       FROM assignment_progress ap JOIN assignments a ON a.id = ap.assignment_id
       JOIN enrollments e ON e.course_id = a.course_id AND e.student_id = @sid
       WHERE ap.student_id = @sid AND ap.score IS NOT NULL) AS average_percent,
    (SELECT COUNT(*) FROM assignment_progress ap WHERE ap.student_id = @sid AND ap.score IS NOT NULL) AS graded_count
`);

const studentCourses = db.prepare(`
  SELECT c.id, c.code, c.name, c.color, u.name AS teacher_name,
    (SELECT COUNT(*) FROM topics t WHERE t.course_id = c.id) AS topic_count,
    (SELECT COUNT(*) FROM topics t JOIN topic_progress p ON p.topic_id = t.id AND p.student_id = @sid
       WHERE t.course_id = c.id AND p.status = 'completed') AS topics_completed,
    (SELECT COUNT(*) FROM topics t JOIN topic_progress p ON p.topic_id = t.id AND p.student_id = @sid
       WHERE t.course_id = c.id AND p.status = 'in_progress') AS topics_in_progress
  FROM courses c
  JOIN enrollments e ON e.course_id = c.id AND e.student_id = @sid
  JOIN users u ON u.id = c.owner_id
  ORDER BY c.code
`);

const studentUpcoming = db.prepare(`
  SELECT a.id, a.title, a.type, a.due_date, a.priority,
         COALESCE(ap.status, 'todo') AS status,
         c.code AS course_code, c.color AS course_color,
         CAST(julianday(a.due_date) - julianday(date('now')) AS INTEGER) AS days_left
  FROM assignments a
  JOIN courses c ON c.id = a.course_id
  JOIN enrollments e ON e.course_id = c.id AND e.student_id = @sid
  LEFT JOIN assignment_progress ap ON ap.assignment_id = a.id AND ap.student_id = @sid
  WHERE COALESCE(ap.status, 'todo') IN ('todo','in_progress','late')
  ORDER BY a.due_date ASC
  LIMIT 8
`);

/* ------------------------------------------------------------- teacher view */

const teacherSummary = db.prepare(`
  SELECT
    (SELECT COUNT(*) FROM courses WHERE owner_id = @uid) AS courses,
    (SELECT COUNT(DISTINCT e.student_id) FROM enrollments e
       JOIN courses c ON c.id = e.course_id WHERE c.owner_id = @uid) AS students,
    (SELECT COUNT(*) FROM assignments a JOIN courses c ON c.id = a.course_id WHERE c.owner_id = @uid) AS assignments,
    (SELECT COUNT(*) FROM assignment_progress ap JOIN assignments a ON a.id = ap.assignment_id
       JOIN courses c ON c.id = a.course_id WHERE c.owner_id = @uid AND ap.status = 'submitted') AS to_grade,
    (SELECT COUNT(*) FROM assignments a JOIN courses c ON c.id = a.course_id
       WHERE c.owner_id = @uid AND a.due_date BETWEEN date('now') AND date('now', '+7 days')) AS due_this_week,
    (SELECT ROUND(AVG(ap.score * 100.0 / a.max_marks), 1)
       FROM assignment_progress ap JOIN assignments a ON a.id = ap.assignment_id
       JOIN courses c ON c.id = a.course_id WHERE c.owner_id = @uid AND ap.score IS NOT NULL) AS average_percent,
    (SELECT COUNT(*) FROM assignment_progress ap JOIN assignments a ON a.id = ap.assignment_id
       JOIN courses c ON c.id = a.course_id WHERE c.owner_id = @uid AND ap.score IS NOT NULL) AS graded_count
`);

const teacherCourses = db.prepare(`
  SELECT c.id, c.code, c.name, c.color, c.join_code,
    (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id) AS student_count,
    (SELECT COUNT(*) FROM topics t WHERE t.course_id = c.id) AS topic_count,
    (SELECT COUNT(*) FROM topic_progress p JOIN topics t ON t.id = p.topic_id
       WHERE t.course_id = c.id AND p.status = 'completed') AS completed_marks,
    (SELECT COUNT(*) FROM assignment_progress ap JOIN assignments a ON a.id = ap.assignment_id
       WHERE a.course_id = c.id AND ap.status = 'submitted') AS to_grade
  FROM courses c WHERE c.owner_id = @uid ORDER BY c.code
`);

const teacherUpcoming = db.prepare(`
  SELECT a.id, a.title, a.type, a.due_date, a.priority, c.code AS course_code, c.color AS course_color,
    (SELECT COUNT(*) FROM assignment_progress ap WHERE ap.assignment_id = a.id AND ap.status = 'submitted') AS submitted_count,
    (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = a.course_id) AS student_count,
    CAST(julianday(a.due_date) - julianday(date('now')) AS INTEGER) AS days_left
  FROM assignments a JOIN courses c ON c.id = a.course_id
  WHERE c.owner_id = @uid AND a.due_date >= date('now')
  ORDER BY a.due_date ASC
  LIMIT 8
`);

const pendingGrading = db.prepare(`
  SELECT ap.updated_at, ap.assignment_id, a.title, a.max_marks,
         u.name AS student_name, c.code AS course_code, c.color AS course_color
  FROM assignment_progress ap
  JOIN assignments a ON a.id = ap.assignment_id
  JOIN courses c ON c.id = a.course_id
  JOIN users u ON u.id = ap.student_id
  WHERE c.owner_id = @uid AND ap.status = 'submitted'
  ORDER BY ap.updated_at DESC
  LIMIT 8
`);

/* -------------------------------------------------------------------- route */

router.get('/', (req, res) => {
  const role = req.user.role;

  if (role === 'teacher') {
    const s = teacherSummary.get({ uid: req.user.id });
    const courses = teacherCourses.all({ uid: req.user.id }).map((c) => {
      const possible = (c.topic_count || 0) * (c.student_count || 0);
      return {
        ...c,
        progress: possible ? Math.round((c.completed_marks / possible) * 100) : 0,
      };
    });
    return res.json({
      role,
      generated_at: new Date().toISOString(),
      summary: s,
      courses,
      upcoming: teacherUpcoming.all({ uid: req.user.id }),
      pending: pendingGrading.all({ uid: req.user.id }),
    });
  }

  const s = studentSummary.get({ sid: req.user.id });
  const courses = studentCourses.all({ sid: req.user.id }).map((c) => ({
    ...c,
    progress: c.topic_count ? Math.round((c.topics_completed / c.topic_count) * 100) : 0,
  }));
  const total = s.topics || 0;

  return res.json({
    role,
    generated_at: new Date().toISOString(),
    summary: {
      ...s,
      syllabus_progress: total ? Math.round((s.topics_completed / total) * 100) : 0,
    },
    courses,
    upcoming: studentUpcoming.all({ sid: req.user.id }),
  });
});

module.exports = router;
