> **Flat edition.** Every file sits at the repository root because GitHub's
> browser upload (the only practical option on a phone) cannot create folders.
> It is the same application — just run `npm start` and open <http://localhost:3000>.

---

# 📚 Syllabus & Student Assignment Tracker

A multi-user full-stack app for a class: **teachers** publish a course syllabus, set assignments and
record marks; **students** join with a code and track their own coverage, submissions and scores.

Works the same on a phone, tablet, laptop or desktop — bottom tab bar and card layout on small
screens, sidebar and data table on large ones.

- **Backend:** Node.js + Express 5 REST API
- **Database:** SQLite (better-sqlite3, file-based, zero setup)
- **Auth:** email + password (scrypt hashes), httpOnly session cookies, role-based access control
- **Frontend:** hand-written HTML / CSS / vanilla JS single-page app — no build step, no framework
- **Tests:** 44 API checks + a real-browser responsive/role suite

---

## Quick start

```bash
cd syllabus-tracker
npm install
npm start          # → http://localhost:3000
```

The database is created and seeded on first run. Sign in with a demo account:

| Role | Email | Password | What you see |
| --- | --- | --- | --- |
| Teacher | `priya@demo.edu` | `demo1234` | 4 courses, 3 enrolled students, submissions to grade |
| Student | `abhi@demo.edu` | `demo1234` | own progress across 4 courses |
| Student | `divya@demo.edu` | `demo1234` | a second student, further behind |

| Script | What it does |
| --- | --- |
| `npm start` | Run the server on port 3000 |
| `npm run dev` | Same, with `--watch` auto-restart |
| `npm run reset` | Delete the SQLite file and re-seed demo data |
| `npm run smoke` | 44-check API + permission test (server must be running) |
| `npm run check` | Real-browser responsive/role audit (needs Playwright, optional) |

Environment: `PORT`, `HOST`, `DB_PATH`. Deploying? See **[DEPLOY.md](DEPLOY.md)**.

---

## Who can do what

| Action | Teacher (course owner) | Student (enrolled) |
| --- | --- | --- |
| Create / edit / delete a course | ✅ | ❌ 403 |
| Add syllabus topics | ✅ | ❌ 403 |
| Mark their own topic coverage | ❌ (no personal progress) | ✅ |
| Set assignments & due dates | ✅ | ❌ 403 |
| Submit work / change own status | ❌ | ✅ |
| See every student's submissions | ✅ | ❌ (own row only) |
| Record marks | ✅ | ❌ 403 |
| View another course's data | ❌ unless they own it | ❌ unless enrolled |

Every rule is enforced **server-side** in `server/access.js`; the UI merely hides what you can't do.

## Features

### Teacher
- Create courses; a **6-character join code** is generated automatically to share with the class
- Build the syllabus unit by unit, with estimated hours
- Set assignments (type, due date, priority, max marks) and link them to syllabus topics
- **Roster** per course: every student's coverage, open work, submissions and average score
- **Submissions dialog** per assignment: see who has handed in and record a mark in one tap
- Dashboard: class progress, submissions waiting to be graded, upcoming deadlines, class average

### Student
- Join a course with its code; see all enrolled courses on one dashboard
- Tick syllabus topics off as *not started → in progress → completed*, rate confidence 0–5
- Per-assignment status (to do / in progress / submitted), personal notes, and marks once graded
- Dashboard: coverage ring, open work, overdue count, average score, what's due next

### Both
- Responsive on phone / tablet / laptop / desktop, with real touch ergonomics
- Search and filter assignments, JSON backup export, print-friendly assignment list
- Keyboard: `Esc` closes dialogs, `n` opens the "new …" form for the current view (teacher)

---

## API

All endpoints are JSON and (except `/api/health` and `/api/auth/*`) require a session cookie.

| Method | Endpoint | Who | Description |
| --- | --- | --- | --- |
| GET | `/api/health` | anyone | Liveness + schema version |
| POST | `/api/auth/register` | anyone | `{name,email,password,role}` → creates account and signs in |
| POST | `/api/auth/login` | anyone | `{email,password}` → sets the session cookie |
| POST | `/api/auth/logout` | signed in | Destroys the session |
| GET | `/api/auth/me` | signed in | Current user |
| GET | `/api/meta` | signed in | Allowed enum values |
| GET | `/api/dashboard` | signed in | Role-aware summary, courses, upcoming work |
| GET | `/api/courses` | signed in | Teacher: owned courses · Student: enrolled courses |
| POST | `/api/courses` | teacher | Create course (join code generated) |
| POST | `/api/courses/join` | student | `{code}` → enrol |
| GET | `/api/courses/:id` | member | Course + topics + assignments (with your progress) |
| PATCH | `/api/courses/:id` | owner | Update course |
| DELETE | `/api/courses/:id` | owner | Delete (cascades) |
| GET | `/api/courses/:id/roster` | owner | Per-student progress |
| GET | `/api/topics?course_id=` | member | Topics with your progress |
| POST | `/api/topics` | owner | Add a syllabus topic |
| PATCH | `/api/topics/:id` | owner | Edit a topic |
| DELETE | `/api/topics/:id` | owner | Delete a topic |
| PATCH | `/api/topics/:id/progress` | student | `{status, confidence}` for **yourself** |
| GET | `/api/assignments?course_id=&status=&type=&priority=&q=&sort=&due=week` | signed in | Role-aware list |
| GET | `/api/assignments/:id` | member | One assignment |
| POST | `/api/assignments` | owner | Create assignment |
| PATCH | `/api/assignments/:id` | owner | Edit assignment |
| DELETE | `/api/assignments/:id` | owner | Delete assignment |
| PATCH | `/api/assignments/:id/progress` | student | `{status, notes}` for yourself |
| GET | `/api/assignments/:id/submissions` | owner | Every enrolled student + their state |
| PATCH | `/api/assignments/:id/grade` | owner | `{student_id, score}` → marks it graded |
| GET | `/api/export` | signed in | JSON backup scoped to your data |

`status` accepts a comma list plus `open` / `overdue`. Errors return
`{ "error": "...", "details": { "field": "message" } }` with `400`, `401`, `403`, `404` or `409`.

### Example

```bash
# sign in and keep the cookie
curl -c jar.txt -X POST http://localhost:3000/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"priya@demo.edu","password":"demo1234"}'

# create an assignment
curl -b jar.txt -X POST http://localhost:3000/api/assignments \
  -H 'Content-Type: application/json' \
  -d '{"course_id":1,"title":"Graph worksheet","type":"homework","due_date":"2026-11-20","max_marks":30}'
```

---

## Data model

```
users (id, name, email UNIQUE, password_hash, role ∈ teacher|student)
  │
  ├─ sessions (id, user_id, expires_at)          ← httpOnly cookie points here
  │
  └─ courses (owner_id → users, code, name, instructor, credits, color, join_code UNIQUE)
       │
       ├─ enrollments (course_id, student_id)    ← students join with the code
       │
       ├─ topics (unit, title, description, est_hours, position)      ← class-wide definition
       │    └─ topic_progress (topic_id, student_id, status, confidence, completed_at)
       │
       └─ assignments (title, type, due_date, priority, max_marks)    ← class-wide definition
            └─ assignment_progress (assignment_id, student_id, status, score, notes)
```

Syllabus topics and assignments are shared by the class; **status, confidence, score and notes are
per student**. Foreign keys cascade, so deleting a course cleans up every dependent row.

---

## Project structure

```
syllabus-tracker/
├── server/
│   ├── index.js            # app wiring: auth, static hosting, API mount, error handler
│   ├── db.js               # schema v2, migration, demo seed
│   ├── auth.js             # scrypt hashing, sessions, login throttle, middleware
│   ├── access.js           # course/topic/assignment permission checks
│   ├── helpers.js          # HttpError, validators, partial-update builder
│   ├── reset.js            # `npm run reset`
│   └── routes/
│       ├── courses.js      # CRUD, join by code, roster
│       ├── topics.js       # teacher CRUD + student progress
│       ├── assignments.js  # teacher CRUD, submissions, grading, student progress
│       └── dashboard.js    # role-aware summaries
├── public/
│   ├── index.html          # app shell (sidebar + bottom tab bar + dialog)
│   ├── styles.css          # design system, responsive/touch layer
│   └── app.js              # auth screen, hash router, views, forms
├── scripts/smoke-test.js   # 44 API + permission checks
├── tests/responsive-check.js
├── DEPLOY.md          # Render / Railway / Docker instructions
├── 
├── render.yaml             # Render blueprint
├── Dockerfile
└── package.json
```

### Architecture notes

- **Sessions, not JWT.** A random 256-bit token is stored in the `sessions` table and sent as an
  httpOnly, SameSite=Lax cookie; `Secure` is set automatically when the request arrives over HTTPS.
  Logging out deletes the row, so it works across devices and survives restarts.
- **Passwords** are hashed with scrypt (16-byte salt, 64-byte key) and compared with
  `timingSafeEqual`. Only failed sign-ins count toward the rate limit.
- **Validation lives on the server**; the browser only trims input and renders `details` next to the
  offending field.
- **No build step.** `public/app.js` is a plain script with a hash router and delegated events.
- **Schema versioning.** `PRAGMA user_version` tracks the schema; a v1 database is replaced on boot.

---

## Cross-device behaviour

| | Phone (≤ 700px) | Tablet (≤ 900px) | Laptop / desktop |
| --- | --- | --- | --- |
| Navigation | bottom tab bar | bottom tab bar | sidebar + account panel |
| Assignments | stacked cards with field labels | cards or table | full data table |
| Filters | collapsed behind a **Filters** button | inline | inline |
| Dialogs | full-width bottom sheet | bottom sheet | centred card |
| Tap targets | 40–44px | 40–44px | compact |

<p>
  <img src="mobile-dashboard.png" width="240" alt="Student dashboard on a phone" />
  <img src="mobile-teacher.png" width="240" alt="Teacher dashboard on a phone" />
  <img src="login.png" width="240" alt="Sign-in screen" />
</p>
<img src="desktop-teacher.png" width="760" alt="Teacher dashboard on a laptop" />

Also handled: 16px form text (no iOS zoom-on-focus), `100dvh` + safe-area insets, scroll-locked
bottom-sheet dialogs, `color-scheme: dark` native controls, and a print stylesheet.

### Verified in real browsers

`tests/responsive-check.js` signs in as both roles and drives Chromium at six viewport profiles
(iPhone SE/12, 360px Android, 820px tablet, 1280px laptop, 1920px desktop), asserting: no page
overflow, correct navigation shell, tables collapse only below 700px, no dialog overlay leaking,
16px inputs, tap targets, and role-specific UI (students submit, teachers grade).

```bash
npm i -D playwright && npx playwright install chromium
npm start                    # in another terminal
npm run check
```

It skips itself gracefully when Playwright isn't installed.

---

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| `Cannot find module 'express'` | Run `npm install` |
| Port already in use | `PORT=4000 npm start` |
| Want a clean slate | `npm run reset` |
| Signed out unexpectedly | Session cookies require a stable origin; don't mix `localhost` and `127.0.0.1` |
| Data vanished after a deploy | Free hosting has no disk — see [DEPLOY.md](DEPLOY.md) |
