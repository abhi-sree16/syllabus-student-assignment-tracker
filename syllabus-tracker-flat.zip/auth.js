'use strict';

const crypto = require('crypto');
const express = require('express');
const { db } = require('./db');
const { HttpError, bad, isNonEmptyString } = require('./helpers');

const COOKIE = 'sid';
const SESSION_DAYS = 30;
const MIN_PASSWORD = 8;

/* ------------------------------------------------------------- passwords */

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const key = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `scrypt$${salt}$${key}`;
}

function verifyPassword(password, stored) {
  const [scheme, salt, key] = String(stored).split('$');
  if (scheme !== 'scrypt' || !salt || !key) return false;
  const derived = crypto.scryptSync(String(password), salt, 64);
  const expected = Buffer.from(key, 'hex');
  return derived.length === expected.length && crypto.timingSafeEqual(derived, expected);
}

/* --------------------------------------------------------------- cookies */

function parseCookies(req) {
  const out = {};
  const header = req.headers.cookie;
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function createSession(userId) {
  const id = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5).toISOString();
  db.prepare('INSERT INTO sessions (id, user_id, expires_at) VALUES (?,?,?)').run(id, userId, expires);
  return id;
}

function setSessionCookie(res, req, token) {
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: req.secure,       // works behind Render/Railway HTTPS proxies
    path: '/',
    maxAge: SESSION_DAYS * 864e5,
  });
}

function clearSessionCookie(res) {
  res.clearCookie(COOKIE, { path: '/' });
}

/* ----------------------------------------------------------- middleware */

/** Attaches req.user when a valid session cookie is present. Never rejects. */
function loadUser(req, res, next) {
  const token = parseCookies(req)[COOKIE];
  if (token) {
    const row = db
      .prepare(
        `SELECT u.id, u.name, u.email, u.role, s.id AS session_id
           FROM sessions s JOIN users u ON u.id = s.user_id
          WHERE s.id = ? AND s.expires_at > datetime('now')`
      )
      .get(token);
    if (row) {
      req.user = { id: row.id, name: row.name, email: row.email, role: row.role };
      req.sessionId = row.session_id;
    }
  }
  next();
}

function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Please sign in to continue' });
  next();
}

const requireRole = (role) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Please sign in to continue' });
  if (req.user.role !== role) {
    return res.status(403).json({ error: `Only a ${role} can do that` });
  }
  next();
};

/* ------------------------------------------------------ login throttling */

const attempts = new Map(); // key → { count, resetAt }
const WINDOW_MS = 10 * 60 * 1000;
const MAX_ATTEMPTS = 10;

function throttle(key) {
  const now = Date.now();
  const entry = attempts.get(key);
  if (!entry || entry.resetAt < now) {
    attempts.set(key, { count: 1, resetAt: now + WINDOW_MS });
    return;
  }
  entry.count += 1;
  if (entry.count > MAX_ATTEMPTS) {
    throw new HttpError(429, 'Too many attempts. Try again in a few minutes.');
  }
  if (attempts.size > 5000) {
    for (const [k, v] of attempts) if (v.resetAt < now) attempts.delete(k);
  }
}

/* ---------------------------------------------------------------- routes */

const router = express.Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role });

/** POST /api/auth/register — create a teacher or student account and sign in. */
router.post('/register', (req, res) => {
  const { name, email, password, role } = req.body || {};
  const errors = {};

  if (!isNonEmptyString(name)) errors.name = 'Your name is required';
  if (!isNonEmptyString(email) || !EMAIL_RE.test(String(email).trim())) errors.email = 'Enter a valid email address';
  if (!isNonEmptyString(password) || String(password).length < MIN_PASSWORD) {
    errors.password = `Password must be at least ${MIN_PASSWORD} characters`;
  }
  if (!['teacher', 'student'].includes(role)) errors.role = 'Choose teacher or student';

  if (Object.keys(errors).length) bad('Please fix the highlighted fields', errors);

  const cleanEmail = String(email).trim().toLowerCase();
  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(cleanEmail);
  if (exists) throw new HttpError(409, 'An account with that email already exists', { email: 'Email already registered' });

  const info = db
    .prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)')
    .run(String(name).trim(), cleanEmail, hashPassword(password), role);

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  setSessionCookie(res, req, createSession(user.id));
  res.status(201).json(publicUser(user));
});

/** POST /api/auth/login */
router.post('/login', (req, res) => {
  const { email, password } = req.body || {};
  if (!isNonEmptyString(email) || !isNonEmptyString(password)) {
    bad('Enter your email and password', {
      ...(isNonEmptyString(email) ? {} : { email: 'Email is required' }),
      ...(isNonEmptyString(password) ? {} : { password: 'Password is required' }),
    });
  }

  const key = `${req.ip}|${String(email).trim().toLowerCase()}`;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email).trim().toLowerCase());
  if (!user || !verifyPassword(password, user.password_hash)) {
    throttle(key); // only failed attempts count towards the limit
    throw new HttpError(401, 'Email or password is incorrect');
  }
  attempts.delete(key); // a good sign-in clears the counter

  db.prepare("DELETE FROM sessions WHERE expires_at <= datetime('now')").run();
  setSessionCookie(res, req, createSession(user.id));
  res.json(publicUser(user));
});

/** POST /api/auth/logout */
router.post('/logout', (req, res) => {
  if (req.sessionId) db.prepare('DELETE FROM sessions WHERE id = ?').run(req.sessionId);
  clearSessionCookie(res);
  res.json({ ok: true });
});

/** GET /api/auth/me */
router.get('/me', requireAuth, (req, res) => {
  res.json(req.user);
});

module.exports = {
  router, loadUser, requireAuth, requireRole,
  hashPassword, verifyPassword, COOKIE,
};
