'use strict';

/**
 * End-to-end smoke test with two roles.
 *   npm start          # in one terminal
 *   npm run smoke      # in another
 */

const BASE = process.env.BASE_URL || 'http://localhost:3000';

let passed = 0;
const failures = [];

function check(name, condition, extra) {
  if (condition) { passed += 1; console.log(`  ✓ ${name}`); }
  else { failures.push(name); console.log(`  ✗ ${name}${extra !== undefined ? ` → ${JSON.stringify(extra)}` : ''}`); }
}

/** Minimal cookie-aware client (sessions are httpOnly cookies). */
class Client {
  constructor(label) { this.label = label; this.cookie = ''; }

  async request(method, path, body) {
    const res = await fetch(`${BASE}${path}`, {
      method,
      headers: {
        ...(body ? { 'Content-Type': 'application/json' } : {}),
        ...(this.cookie ? { Cookie: this.cookie } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const setCookies = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
    for (const raw of setCookies) {
      const pair = raw.split(';')[0];
      if (!pair.startsWith('sid=')) continue;
      this.lastSetCookie = raw;                       // keep attributes for assertions
      this.cookie = pair.endsWith('sid=') ? '' : pair; // empty value = logged out
    }
    const text = await res.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    return { status: res.status, data };
  }

  get(p) { return this.request('GET', p); }
  post(p, b) { return this.request('POST', p, b); }
  patch(p, b) { return this.request('PATCH', p, b); }
  del(p) { return this.request('DELETE', p); }

  async login(email, password) {
    const res = await this.post('/api/auth/login', { email, password });
    if (res.status !== 200) throw new Error(`${this.label} login failed: ${JSON.stringify(res.data)}`);
    return res;
  }
}

(async () => {
  console.log(`\nSmoke testing ${BASE}\n`);

  const anon = new Client('anon');
  const teacher = new Client('teacher');
  const student = new Client('student');

  console.log('— public surface');
  const health = await anon.get('/api/health');
  check('GET /api/health responds ok', health.status === 200 && health.data.ok === true, health.data);
  check('health reports the schema version', health.data.schema === 2, health.data.schema);

  const guarded = await anon.get('/api/courses');
  check('courses require a session (401)', guarded.status === 401, guarded.status);

  const badLogin = await anon.post('/api/auth/login', { email: 'priya@demo.edu', password: 'wrong-password' });
  check('wrong password is rejected (401)', badLogin.status === 401, badLogin.status);

  console.log('\n— teacher session');
  const loginT = await teacher.login('priya@demo.edu', 'demo1234');
  check('teacher can sign in', loginT.status === 200 && loginT.data.role === 'teacher', loginT.data);
  check('session cookie is httpOnly + SameSite', /httponly/i.test(teacher.lastSetCookie || '') && /samesite=lax/i.test(teacher.lastSetCookie || ''), teacher.lastSetCookie);

  const meT = await teacher.get('/api/auth/me');
  check('GET /api/auth/me returns the teacher', meT.status === 200 && meT.data.email === 'priya@demo.edu', meT.data);

  const teacherCourses = await teacher.get('/api/courses');
  check('teacher sees their own courses', teacherCourses.status === 200 && teacherCourses.data.length === 4, teacherCourses.data?.length);
  check('course carries a join code', /^[A-Z0-9]{6}$/.test(teacherCourses.data[0].join_code), teacherCourses.data[0].join_code);

  const courseId = teacherCourses.data[0].id;
  const roster = await teacher.get(`/api/courses/${courseId}/roster`);
  check('teacher can read the roster', roster.status === 200 && roster.data.students.length === 3, roster.data?.students?.length);

  console.log('\n— course + syllabus management (teacher)');
  const code = `TST${Date.now().toString().slice(-5)}`;
  const created = await teacher.post('/api/courses', {
    code, name: 'Temporary Test Course', instructor: 'QA Bot', credits: 3, color: '#8b5cf6',
  });
  check('POST /api/courses creates a course', created.status === 201 && created.data.code === code, created.data);
  const newCourseId = created.data?.id;
  const joinCode = created.data?.join_code;

  const dupe = await teacher.post('/api/courses', { code, name: 'Duplicate' });
  check('duplicate course code is rejected (409)', dupe.status === 409, dupe.status);

  const invalid = await teacher.post('/api/courses', { name: '   ' });
  check('validation errors return field details', invalid.status === 400 && !!invalid.data.details, invalid.data);

  const topic = await teacher.post('/api/topics', {
    course_id: newCourseId, unit: 'Unit 1', title: 'Intro to Testing', est_hours: 2.5,
  });
  check('teacher can add a syllabus topic', topic.status === 201, topic.data);
  const topicId = topic.data?.id;

  const patchedTopic = await teacher.patch(`/api/topics/${topicId}`, { title: 'Intro to Testing v2' });
  check('teacher can edit a topic', patchedTopic.status === 200 && patchedTopic.data.title === 'Intro to Testing v2');

  const tomorrow = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  const assignment = await teacher.post('/api/assignments', {
    course_id: newCourseId, topic_id: topicId, title: 'Testing Worksheet',
    type: 'homework', due_date: tomorrow, priority: 'high', max_marks: 20,
  });
  check('teacher can create an assignment', assignment.status === 201, assignment.data);
  const assignmentId = assignment.data?.id;

  const badDate = await teacher.post('/api/assignments', {
    course_id: newCourseId, title: 'Bad date', due_date: '09-11-2026',
  });
  check('invalid due date is rejected (400)', badDate.status === 400, badDate.status);

  console.log('\n— student session and permissions');
  await student.login('abhi@demo.edu', 'demo1234');
  const meS = await student.get('/api/auth/me');
  check('student can sign in and read their profile', meS.status === 200 && meS.data.role === 'student', meS.data);

  const studentCourses = await student.get('/api/courses');
  check('student sees enrolled courses', studentCourses.status === 200 && studentCourses.data.length === 4, studentCourses.data?.length);

  const forbiddenCourse = await student.post('/api/courses', { code: 'HACK1', name: 'Nope' });
  check('student cannot create courses (403)', forbiddenCourse.status === 403, forbiddenCourse.status);

  const forbiddenTopic = await student.post('/api/topics', { course_id: newCourseId, title: 'Nope' });
  check('student cannot add syllabus topics (403)', forbiddenTopic.status === 403, forbiddenTopic.status);

  const notEnrolled = await student.get(`/api/courses/${newCourseId}`);
  check('student cannot open a course they have not joined (403)', notEnrolled.status === 403, notEnrolled.status);

  console.log('\n— joining by code');
  const joined = await student.post('/api/courses/join', { code: joinCode });
  check('student joins with the join code', joined.status === 201 && joined.data.code === code, joined.data);
  const rejoin = await student.post('/api/courses/join', { code: joinCode });
  check('joining twice is rejected (409)', rejoin.status === 409, rejoin.status);
  const badCode = await student.post('/api/courses/join', { code: 'ZZZZZZ' });
  check('unknown join code is rejected (404)', badCode.status === 404, badCode.status);

  console.log('\n— per-student progress');
  const topicProgress = await student.patch(`/api/topics/${topicId}/progress`, { status: 'completed', confidence: 4 });
  check('student marks their own topic complete', topicProgress.status === 200 && topicProgress.data.status === 'completed');
  check('completed_at is stamped', !!topicProgress.data.completed_at, topicProgress.data);

  const teacherOwnProgress = await teacher.patch(`/api/topics/${topicId}/progress`, { status: 'completed' });
  check('teacher has no personal progress (403)', teacherOwnProgress.status === 403, teacherOwnProgress.status);

  const submitted = await student.patch(`/api/assignments/${assignmentId}/progress`, {
    status: 'submitted', notes: 'Uploaded to the portal',
  });
  check('student submits an assignment', submitted.status === 200 && submitted.data.status === 'submitted', submitted.data);

  const studentGrading = await student.patch(`/api/assignments/${assignmentId}/grade`, { student_id: meS.data.id, score: 20 });
  check('student cannot grade (403)', studentGrading.status === 403, studentGrading.status);

  console.log('\n— grading');
  const submissions = await teacher.get(`/api/assignments/${assignmentId}/submissions`);
  const abhiId = submissions.data?.students?.find((s) => s.email === 'abhi@demo.edu')?.id;
  check('teacher sees the submission in the list',
    submissions.status === 200 && submissions.data.students.some((s) => s.status === 'submitted'), submissions.data?.students);

  const graded = await teacher.patch(`/api/assignments/${assignmentId}/grade`, { student_id: abhiId, score: 18 });
  check('teacher records a mark', graded.status === 200 && graded.data.score === 18 && graded.data.status === 'graded', graded.data);

  const overMark = await teacher.patch(`/api/assignments/${assignmentId}/grade`, { student_id: abhiId, score: 999 });
  check('mark above max is rejected (400)', overMark.status === 400, overMark.data);

  const studentView = await student.get(`/api/assignments/${assignmentId}`);
  check('student sees their own mark', studentView.data?.score === 18 && studentView.data?.status === 'graded', studentView.data?.score);

  const classmate = new Client('classmate');
  const leak = await classmate.get(`/api/assignments/${assignmentId}`);
  check('anonymous request cannot read the assignment (401)', leak.status === 401, leak.status);

  console.log('\n— dashboards');
  const dashT = await teacher.get('/api/dashboard');
  check('teacher dashboard has class stats',
    dashT.status === 200 && dashT.data.role === 'teacher' && typeof dashT.data.summary.students === 'number', dashT.data?.summary);
  check('teacher dashboard counts submissions to grade', dashT.data.summary.to_grade >= 0, dashT.data.summary.to_grade);

  const dashS = await student.get('/api/dashboard');
  check('student dashboard is personal',
    dashS.status === 200 && dashS.data.role === 'student' && typeof dashS.data.summary.syllabus_progress === 'number', dashS.data?.summary);

  console.log('\n— accounts');
  const email = `qa${Date.now().toString().slice(-6)}@test.edu`;
  const weak = await anon.post('/api/auth/register', { name: 'QA', email, password: 'short', role: 'student' });
  check('short passwords are rejected (400)', weak.status === 400 && !!weak.data.details?.password, weak.data);

  const registered = await new Client('fresh').post('/api/auth/register', {
    name: 'QA Student', email, password: 'supersecret', role: 'student',
  });
  check('new account can register', registered.status === 201 && registered.data.role === 'student', registered.data);

  const duplicateEmail = await anon.post('/api/auth/register', {
    name: 'QA Two', email, password: 'supersecret', role: 'student',
  });
  check('duplicate email is rejected (409)', duplicateEmail.status === 409, duplicateEmail.status);

  console.log('\n— cleanup + logout');
  const delCourse = await teacher.del(`/api/courses/${newCourseId}`);
  check('teacher can delete the test course', delCourse.status === 200, delCourse.data);

  const goneTopic = await teacher.get(`/api/topics?course_id=${newCourseId}`);
  check('deleting a course removes its topics', goneTopic.status === 403 || goneTopic.status === 404 || (goneTopic.data || []).length === 0, goneTopic.status);

  await student.post('/api/auth/logout');
  const afterLogout = await student.get('/api/auth/me');
  check('logout invalidates the session (401)', afterLogout.status === 401, afterLogout.status);

  console.log(`\n${passed} passed, ${failures.length} failed`);
  if (failures.length) {
    console.log('Failed checks:', failures.join(', '));
    process.exit(1);
  }
})();
