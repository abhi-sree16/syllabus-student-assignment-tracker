'use strict';

const path = require('path');
const express = require('express');
const cors = require('cors');

const { db, DB_PATH, migrate, seedIfEmpty, DEMO_PASSWORD, SCHEMA_VERSION } = require('./db');
const { router: authRouter, loadUser, requireAuth, hashPassword } = require('./auth');
const { HttpError } = require('./helpers');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';

const migration = migrate();
const seeded = seedIfEmpty(hashPassword);
if (seeded) {
  console.log('→ demo data seeded (schema v' + SCHEMA_VERSION + ')');
  console.log('  teacher: priya@demo.edu / ' + DEMO_PASSWORD);
  console.log('  student: abhi@demo.edu  / ' + DEMO_PASSWORD);
} else {
  console.log(`→ schema v${SCHEMA_VERSION} (${migration}), database at ${DB_PATH}`);
}

const app = express();

app.set('trust proxy', 1);      // correct req.secure behind Render/Railway/Fly proxies
app.disable('x-powered-by');
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(loadUser);              // attaches req.user when the session cookie is valid
app.use(express.static(__dirname, { extensions: ['html'] }));

/* ---------------------------------------------------------------------- api */

app.get('/api/health', (req, res) => {
  const users = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  const courses = db.prepare('SELECT COUNT(*) AS n FROM courses').get().n;
  res.json({
    ok: true,
    schema: SCHEMA_VERSION,
    database: path.basename(DB_PATH),
    users,
    courses,
    uptime_s: Math.round(process.uptime()),
  });
});

app.use('/api/auth', authRouter);

/** Metadata used by the front-end selects. */
app.get('/api/meta', requireAuth, (req, res) => {
  res.json({
    topic_statuses: ['not_started', 'in_progress', 'completed'],
    assignment_statuses: ['todo', 'in_progress', 'submitted', 'graded', 'late'],
    assignment_types: ['homework', 'quiz', 'lab', 'project', 'exam', 'reading', 'presentation'],
    priorities: ['low', 'medium', 'high'],
    roles: ['teacher', 'student'],
  });
});

app.use('/api/courses', requireAuth, require('./routes-courses'));
app.use('/api/topics', requireAuth, require('./routes-topics'));
app.use('/api/assignments', requireAuth, require('./routes-assignments'));
app.use('/api/dashboard', requireAuth, require('./routes-dashboard'));

/** JSON backup, scoped to what the caller is allowed to see. */
app.get('/api/export', requireAuth, (req, res) => {
  const teacher = req.user.role === 'teacher';
  const courses = teacher
    ? db.prepare('SELECT * FROM courses WHERE owner_id = ? ORDER BY id').all(req.user.id)
    : db.prepare(`SELECT c.* FROM courses c
                  JOIN enrollments e ON e.course_id = c.id AND e.student_id = ?
                  ORDER BY c.id`).all(req.user.id);

  const ids = courses.map((c) => c.id);
  const slots = ids.map(() => '?').join(',') || 'NULL';
  const topics = ids.length ? db.prepare(`SELECT * FROM topics WHERE course_id IN (${slots}) ORDER BY id`).all(...ids) : [];
  const assignments = ids.length
    ? db.prepare(`SELECT * FROM assignments WHERE course_id IN (${slots}) ORDER BY id`).all(...ids)
    : [];

  const topicIds = topics.map((t) => t.id);
  const assignmentIds = assignments.map((a) => a.id);
  const tSlots = topicIds.map(() => '?').join(',') || 'NULL';
  const aSlots = assignmentIds.map(() => '?').join(',') || 'NULL';

  const topicProgress = teacher
    ? (topicIds.length ? db.prepare(`SELECT * FROM topic_progress WHERE topic_id IN (${tSlots})`).all(...topicIds) : [])
    : (topicIds.length
      ? db.prepare(`SELECT * FROM topic_progress WHERE student_id = ? AND topic_id IN (${tSlots})`)
        .all(req.user.id, ...topicIds)
      : []);

  const assignmentProgress = teacher
    ? (assignmentIds.length ? db.prepare(`SELECT * FROM assignment_progress WHERE assignment_id IN (${aSlots})`).all(...assignmentIds) : [])
    : (assignmentIds.length
      ? db.prepare(`SELECT * FROM assignment_progress WHERE student_id = ? AND assignment_id IN (${aSlots})`)
        .all(req.user.id, ...assignmentIds)
      : []);

  res.setHeader('Content-Disposition', 'attachment; filename="syllabus-tracker-backup.json"');
  res.json({
    exported_at: new Date().toISOString(),
    exported_by: { name: req.user.name, role: req.user.role },
    courses, topics, assignments, topic_progress: topicProgress, assignment_progress: assignmentProgress,
  });
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Unknown API endpoint' }));

/* ----------------------------------------------------------------- fallback */

app.use((req, res, next) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return next();
  res.sendFile(path.join(__dirname, 'index.html'));
});

/* ------------------------------------------------------------------- errors */

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof HttpError) {
    return res.status(err.status).json({ error: err.message, details: err.details });
  }
  if (err && err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
    return res.status(409).json({ error: 'That value already exists' });
  }
  console.error('[error]', err);
  res.status(500).json({ error: 'Something went wrong on the server' });
});

const server = app.listen(PORT, HOST, () => {
  console.log(`Syllabus & Assignment Tracker → http://localhost:${PORT}`);
});

const shutdown = () => {
  server.close(() => {
    db.close();
    process.exit(0);
  });
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

module.exports = app;
