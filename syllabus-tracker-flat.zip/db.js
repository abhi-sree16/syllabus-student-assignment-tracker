'use strict';

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'tracker.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

const SCHEMA_VERSION = 2;

/* ------------------------------------------------------------------ schema */

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  email         TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT    NOT NULL,
  role          TEXT    NOT NULL CHECK (role IN ('teacher','student')),
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  id         TEXT    PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT    NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT    NOT NULL
);

/* A course belongs to a teacher. Syllabus + assignments are class-wide;
   per-student state lives in topic_progress / assignment_progress. */
CREATE TABLE IF NOT EXISTS courses (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code        TEXT    NOT NULL,
  name        TEXT    NOT NULL,
  instructor  TEXT    NOT NULL DEFAULT '',
  semester    TEXT    NOT NULL DEFAULT '',
  credits     INTEGER NOT NULL DEFAULT 3,
  color       TEXT    NOT NULL DEFAULT '#6366f1',
  join_code   TEXT    NOT NULL UNIQUE,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  UNIQUE (owner_id, code)
);

CREATE TABLE IF NOT EXISTS enrollments (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  course_id  INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT    NOT NULL DEFAULT (datetime('now')),
  UNIQUE (course_id, student_id)
);

CREATE TABLE IF NOT EXISTS topics (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  course_id   INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  unit        TEXT    NOT NULL DEFAULT 'Unit 1',
  title       TEXT    NOT NULL,
  description TEXT    NOT NULL DEFAULT '',
  est_hours   REAL    NOT NULL DEFAULT 1,
  position    INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS topic_progress (
  topic_id     INTEGER NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  student_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status       TEXT    NOT NULL DEFAULT 'not_started'
                 CHECK (status IN ('not_started','in_progress','completed')),
  confidence   INTEGER NOT NULL DEFAULT 0 CHECK (confidence BETWEEN 0 AND 5),
  completed_at TEXT,
  updated_at   TEXT    NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (topic_id, student_id)
);

CREATE TABLE IF NOT EXISTS assignments (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  course_id   INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  topic_id    INTEGER REFERENCES topics(id) ON DELETE SET NULL,
  title       TEXT    NOT NULL,
  description TEXT    NOT NULL DEFAULT '',
  type        TEXT    NOT NULL DEFAULT 'homework'
                CHECK (type IN ('homework','quiz','lab','project','exam','reading','presentation')),
  due_date    TEXT    NOT NULL,
  priority    TEXT    NOT NULL DEFAULT 'medium' CHECK (priority IN ('low','medium','high')),
  max_marks   REAL    NOT NULL DEFAULT 100,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS assignment_progress (
  assignment_id INTEGER NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
  student_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status        TEXT    NOT NULL DEFAULT 'todo'
                  CHECK (status IN ('todo','in_progress','submitted','graded','late')),
  score         REAL,
  notes         TEXT    NOT NULL DEFAULT '',
  updated_at    TEXT    NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (assignment_id, student_id)
);

CREATE INDEX IF NOT EXISTS idx_topics_course        ON topics(course_id);
CREATE INDEX IF NOT EXISTS idx_assignments_course   ON assignments(course_id);
CREATE INDEX IF NOT EXISTS idx_assignments_due      ON assignments(due_date);
CREATE INDEX IF NOT EXISTS idx_enrollments_student  ON enrollments(student_id);
CREATE INDEX IF NOT EXISTS idx_sessions_user        ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_topic_progress_stu   ON topic_progress(student_id);
`;

const TABLES = [
  'assignment_progress', 'topic_progress', 'assignments', 'topics',
  'enrollments', 'courses', 'sessions', 'users',
];

function migrate() {
  const hasUsers = db
    .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
    .get();

  if (!hasUsers) {
    // Either a brand new database, or the v1 demo schema — start clean either way.
    for (const t of TABLES) db.exec(`DROP TABLE IF EXISTS ${t}`);
    db.exec(SCHEMA);
    db.pragma(`user_version = ${SCHEMA_VERSION}`);
    return 'created';
  }

  db.exec(SCHEMA); // idempotent, covers additive upgrades
  db.pragma(`user_version = ${SCHEMA_VERSION}`);
  return 'existing';
}

/* --------------------------------------------------------------- utilities */

const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no I/O/0/1
function generateJoinCode(length = 6) {
  let code = '';
  const bytes = crypto.randomBytes(length);
  for (let i = 0; i < length; i += 1) code += CODE_ALPHABET[bytes[i] % CODE_ALPHABET.length];
  const clash = db.prepare('SELECT 1 FROM courses WHERE join_code = ?').get(code);
  return clash ? generateJoinCode(length) : code;
}

const iso = (d) => d.toISOString().slice(0, 10);
const dayOffset = (n) => {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  d.setDate(d.getDate() + n);
  return iso(d);
};

/* --------------------------------------------------------------- demo data */

const DEMO_PASSWORD = 'demo1234';

const DEMO_USERS = [
  { name: 'Priya Sharma', email: 'priya@demo.edu', role: 'teacher' },
  { name: 'Abhi Sree', email: 'abhi@demo.edu', role: 'student' },
  { name: 'Divya Rao', email: 'divya@demo.edu', role: 'student' },
  { name: 'Kiran Varma', email: 'kiran@demo.edu', role: 'student' },
];

const DEMO_COURSES = [
  { code: 'CS301', name: 'Data Structures & Algorithms', instructor: 'Dr. R. Prasad', semester: 'Semester 5', credits: 4, color: '#6366f1' },
  { code: 'CS302', name: 'Database Management Systems', instructor: 'Prof. S. Lakshmi', semester: 'Semester 5', credits: 3, color: '#0ea5e9' },
  { code: 'CS303', name: 'Operating Systems', instructor: 'Dr. K. Varma', semester: 'Semester 5', credits: 3, color: '#f59e0b' },
  { code: 'CS304', name: 'Computer Networks', instructor: 'Prof. A. Rao', semester: 'Semester 5', credits: 3, color: '#10b981' },
];

const DEMO_TOPICS = {
  CS301: [
    ['Unit 1', 'Arrays, Strings & Complexity Analysis', 'Asymptotic notation, amortised analysis, array/string two-pointer patterns.', 3],
    ['Unit 2', 'Linked Lists & Stacks', 'Singly/doubly linked lists, stack ADT, expression evaluation.', 3],
    ['Unit 3', 'Trees & Binary Search Trees', 'Traversals, BST operations, AVL rotations, heaps and priority queues.', 5],
    ['Unit 4', 'Graphs', 'BFS/DFS, topological sort, Dijkstra, MST (Prim/Kruskal).', 6],
    ['Unit 5', 'Dynamic Programming & Greedy', 'Memoisation vs tabulation, knapsack, LCS, greedy scheduling.', 6],
    ['Unit 6', 'Hashing & Sorting', 'Hash maps, collision handling, merge/quick/heap sort trade-offs.', 4],
  ],
  CS302: [
    ['Unit 1', 'Relational Model & ER Design', 'Entities, relationships, keys, ER-to-relational mapping.', 3],
    ['Unit 2', 'SQL & Relational Algebra', 'Joins, aggregation, subqueries, window functions.', 4],
    ['Unit 3', 'Normalisation', 'Functional dependencies, 1NF-BCNF, decomposition and losslessness.', 4],
    ['Unit 4', 'Transactions & Concurrency Control', 'ACID, 2PL, deadlock handling, isolation levels.', 5],
    ['Unit 5', 'Indexing & Query Optimisation', 'B+ trees, hashing, cost-based plans, EXPLAIN analysis.', 4],
  ],
  CS303: [
    ['Unit 1', 'OS Structure & Processes', 'Kernel vs user mode, process states, context switching.', 3],
    ['Unit 2', 'CPU Scheduling', 'FCFS, SJF, round robin, priority, multilevel queues.', 3],
    ['Unit 3', 'Synchronisation & Deadlocks', 'Semaphores, monitors, banker\'s algorithm, detection.', 5],
    ['Unit 4', 'Memory Management', 'Paging, segmentation, TLB, page replacement algorithms.', 5],
    ['Unit 5', 'File Systems & I/O', 'Inodes, allocation methods, disk scheduling.', 4],
  ],
  CS304: [
    ['Unit 1', 'Reference Models & Physical Layer', 'OSI/TCP-IP, transmission media, encoding.', 2],
    ['Unit 2', 'Data Link Layer', 'Framing, error detection, CRC, sliding window protocols.', 4],
    ['Unit 3', 'MAC & Ethernet', 'CSMA/CD, CSMA/CA, switches, VLANs.', 3],
    ['Unit 4', 'Network Layer', 'IPv4/IPv6 addressing, subnetting, routing algorithms.', 6],
    ['Unit 5', 'Transport & Application Layer', 'TCP/UDP, congestion control, DNS, HTTP.', 4],
  ],
};

const DEMO_ASSIGNMENTS = [
  ['CS301', 'AVL Tree Implementation', 'Implement insert/delete with rotations plus unit tests in Java.', 'lab', 2, 'high', 50, 'Unit 3'],
  ['CS301', 'Graph Algorithms Worksheet', 'Run Dijkstra by hand on 3 graphs; compare with Prim output.', 'homework', 6, 'medium', 30, 'Unit 4'],
  ['CS301', 'Mid-Term Examination', 'Units 1-4, closed book, 90 minutes.', 'exam', 12, 'high', 100, 'Unit 4'],
  ['CS302', 'Normalisation Problem Set', 'Normalise 5 schemas up to BCNF with justification.', 'homework', 1, 'high', 40, 'Unit 3'],
  ['CS302', 'SQL Query Lab', '20 queries on the university schema, submit .sql + screenshots.', 'lab', -3, 'medium', 50, 'Unit 2'],
  ['CS302', 'Mini Project: Library DB', 'Design schema, seed data, write 10 analytical queries.', 'project', 20, 'high', 100, 'Unit 5'],
  ['CS303', 'Scheduling Simulation', 'Simulate FCFS/SJF/RR and plot average waiting time.', 'lab', 4, 'medium', 40, 'Unit 2'],
  ['CS303', 'Deadlock Case Study', 'Analyse a deadlock trace, apply banker\'s algorithm.', 'homework', -6, 'low', 25, 'Unit 3'],
  ['CS303', 'Quiz 2: Synchronisation', 'Short quiz on semaphores and monitors.', 'quiz', 8, 'medium', 20, 'Unit 3'],
  ['CS304', 'Subnetting Worksheet', 'Subnet 192.168.10.0/24 into 6 usable networks.', 'homework', 3, 'medium', 30, 'Unit 4'],
  ['CS304', 'Packet Capture Report', 'Capture a TCP handshake in Wireshark and annotate the flags.', 'lab', -1, 'high', 40, 'Unit 5'],
  ['CS304', 'Reading: RFC 791', 'Summarise IPv4 header fields and fragmentation rules.', 'reading', 5, 'low', 10, 'Unit 4'],
];

/** Deterministic pseudo-random so the demo looks the same for everyone. */
const mix = (a, b, mod) => Math.abs((a * 7 + b * 13 + 5) % mod);

function seedIfEmpty(hashPassword) {
  const { n } = db.prepare('SELECT COUNT(*) AS n FROM users').get();
  if (n > 0) return false;

  const seed = db.transaction(() => {
    const insUser = db.prepare(
      'INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)'
    );
    const userIds = {};
    for (const u of DEMO_USERS) {
      const info = insUser.run(u.name, u.email, hashPassword(DEMO_PASSWORD), u.role);
      userIds[u.email] = info.lastInsertRowid;
    }
    const teacherId = userIds['priya@demo.edu'];
    const studentIds = DEMO_USERS.filter((u) => u.role === 'student').map((u) => userIds[u.email]);

    const insCourse = db.prepare(
      `INSERT INTO courses (owner_id, code, name, instructor, semester, credits, color, join_code)
       VALUES (?,?,?,?,?,?,?,?)`
    );
    const insEnroll = db.prepare('INSERT INTO enrollments (course_id, student_id) VALUES (?,?)');
    const insTopic = db.prepare(
      `INSERT INTO topics (course_id, unit, title, description, est_hours, position)
       VALUES (?,?,?,?,?,?)`
    );
    const insTopicProgress = db.prepare(
      `INSERT INTO topic_progress (topic_id, student_id, status, confidence, completed_at)
       VALUES (?,?,?,?,?)`
    );
    const insAssignment = db.prepare(
      `INSERT INTO assignments (course_id, topic_id, title, description, type, due_date, priority, max_marks)
       VALUES (?,?,?,?,?,?,?,?)`
    );
    const insAssignmentProgress = db.prepare(
      `INSERT INTO assignment_progress (assignment_id, student_id, status, score, notes)
       VALUES (?,?,?,?,?)`
    );

    const courseIds = {};
    const topicIds = {};

    DEMO_COURSES.forEach((c) => {
      const info = insCourse.run(
        teacherId, c.code, c.name, c.instructor, c.semester, c.credits, c.color, generateJoinCode()
      );
      courseIds[c.code] = info.lastInsertRowid;

      // every demo student is enrolled in every demo course
      studentIds.forEach((sid) => insEnroll.run(courseIds[c.code], sid));

      DEMO_TOPICS[c.code].forEach(([unit, title, description, est_hours], pos) => {
        const t = insTopic.run(courseIds[c.code], unit, title, description, est_hours, pos);
        topicIds[`${c.code}|${unit}`] = t.lastInsertRowid;

        studentIds.forEach((sid, si) => {
          // each successive student is a little further along
          const status = pos < 2 + si ? 'completed' : pos === 2 + si ? 'in_progress' : 'not_started';
          const confidence = status === 'completed' ? 3 + mix(si, pos, 3) : status === 'in_progress' ? 2 : 0;
          insTopicProgress.run(
            t.lastInsertRowid, sid, status, confidence,
            status === 'completed' ? dayOffset(-(9 - pos)) : null
          );
        });
      });
    });

    DEMO_ASSIGNMENTS.forEach(([code, title, description, type, dueOffset, priority, maxMarks, unit], idx) => {
      const info = insAssignment.run(
        courseIds[code], topicIds[`${code}|${unit}`] ?? null, title, description,
        type, dayOffset(dueOffset), priority, maxMarks
      );
      const assignmentId = info.lastInsertRowid;

      studentIds.forEach((sid, si) => {
        const scenario = mix(idx, si, 5); // 0..4
        let status = 'todo';
        let score = null;
        if (scenario === 1) status = 'in_progress';
        else if (scenario === 3) status = 'submitted';
        else if (scenario === 4) { status = 'graded'; score = Math.round(maxMarks * (0.7 + (si % 3) * 0.1)); }
        if (dueOffset < 0 && status === 'todo') status = 'late';
        insAssignmentProgress.run(
          assignmentId, sid, status, score,
          status === 'graded' ? 'Feedback: see comments in class.' : ''
        );
      });
    });
  });

  seed();
  return true;
}

module.exports = {
  db, DB_PATH, migrate, seedIfEmpty, generateJoinCode, dayOffset, DEMO_PASSWORD, SCHEMA_VERSION,
};
