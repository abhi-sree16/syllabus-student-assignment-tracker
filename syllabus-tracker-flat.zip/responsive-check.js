'use strict';

/**
 * Cross-device + role check in a real browser.
 *
 *   npm start
 *   npm i -D playwright && npx playwright install chromium
 *   node tests/responsive-check.js
 *
 * Signs in as the seeded student and teacher, then verifies on phone / tablet /
 * laptop / desktop viewports:
 *   • sign-in screen shows for anonymous visitors
 *   • no horizontal page overflow, correct navigation shell per width
 *   • tables become cards below 700px
 *   • dialogs never leak onto the page and stay usable at both sizes
 *   • tap targets and form font sizes
 *   • role-specific UI (students submit, teachers grade)
 *
 * Skips itself (exit 0) when Playwright is not installed.
 */

const BASE = process.env.BASE_URL || 'http://localhost:3000';

let chromium;
try {
  ({ chromium } = require('playwright'));
} catch {
  console.log('Playwright is not installed — skipping. Run: npm i -D playwright && npx playwright install chromium');
  process.exit(0);
}

const DEVICES = [
  { name: 'iphone-se    ', width: 375, height: 667, dpr: 2, mobile: true },
  { name: 'iphone-12    ', width: 390, height: 844, dpr: 3, mobile: true },
  { name: 'android-360  ', width: 360, height: 740, dpr: 2, mobile: true },
  { name: 'tablet-820   ', width: 820, height: 1180, dpr: 2, mobile: true },
  { name: 'laptop-1280  ', width: 1280, height: 800, dpr: 1, mobile: false },
  { name: 'desktop-1920 ', width: 1920, height: 1080, dpr: 1, mobile: false },
];
const VIEWS = ['dashboard', 'courses', 'syllabus', 'assignments'];
const ACCOUNTS = {
  student: { email: 'abhi@demo.edu', password: 'demo1234' },
  teacher: { email: 'priya@demo.edu', password: 'demo1234' },
};

let failures = 0;
const check = (condition, label, detail = '') => {
  if (!condition) failures += 1;
  console.log(`  ${condition ? '✓' : '✗'} ${label}${detail ? ` — ${detail}` : ''}`);
};

async function signIn(page, role) {
  await page.goto(BASE, { waitUntil: 'networkidle' });
  await page.fill('#auth-email', ACCOUNTS[role].email);
  await page.fill('#auth-password', ACCOUNTS[role].password);
  await page.click('#auth-submit');
  await page.waitForTimeout(1100);
}

(async () => {
  console.log(`\nResponsive + role check against ${BASE}\n`);

  // anonymous visitors get the sign-in screen
  {
    const browser = await chromium.launch();
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
    const page = await ctx.newPage();
    await page.goto(BASE, { waitUntil: 'networkidle' });
    await page.waitForTimeout(500);
    const anon = await page.evaluate(() => ({
      authVisible: !!document.querySelector('.auth-card'),
      field: (() => {
        const el = document.querySelector('#auth-email');
        const cs = getComputedStyle(el);
        return { bg: cs.backgroundColor, font: parseFloat(cs.fontSize), height: Math.round(el.getBoundingClientRect().height) };
      })(),
      navHidden: getComputedStyle(document.querySelector('#bottom-nav')).display === 'none'
        && getComputedStyle(document.querySelector('.sidebar')).display === 'none',
    }));
    console.log('anonymous');
    check(anon.authVisible, 'sign-in card shown to visitors');
    check(anon.navHidden, 'app navigation hidden until signed in');
    check(anon.field.bg === 'rgb(15, 23, 43)', 'sign-in fields use the app theme', anon.field.bg);
    check(anon.field.font >= 16, 'sign-in fields are >=16px (no iOS zoom)', `${anon.field.font}px`);
    check(anon.field.height >= 38, 'sign-in fields are comfortably tall', `${anon.field.height}px`);
    await browser.close();
    console.log('');
  }

  const browser = await chromium.launch();

  for (const role of ['student', 'teacher']) {
    // the teacher pass runs on a representative subset to keep runtime sane
    const devices = role === 'teacher'
      ? DEVICES.filter((d) => [360, 820, 1280].includes(d.width))
      : DEVICES;

    for (const d of devices) {
      const ctx = await browser.newContext({
        viewport: { width: d.width, height: d.height },
        deviceScaleFactor: d.dpr,
        isMobile: d.mobile,
        hasTouch: d.mobile,
      });
      const page = await ctx.newPage();
      const errors = [];
      page.on('pageerror', (e) => errors.push(e.message));
      page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });

      await signIn(page, role);
      const signedIn = await page.evaluate(() => !document.body.classList.contains('auth-mode'));
      if (!signedIn) { check(false, `${role} sign-in on ${d.name}`); await ctx.close(); continue; }
      // the anonymous session probe above is expected to answer 401 — not an app error
      errors.length = 0;

      console.log(`${d.name} ${role} — ${d.width}x${d.height}`);
      for (const view of VIEWS) {
        await page.goto(`${BASE}/#/${view}`, { waitUntil: 'networkidle' });
        await page.waitForTimeout(420);

        const r = await page.evaluate(() => {
          const de = document.documentElement;
          const small = [];
          document.querySelectorAll('button, a, select, input, .status-btn, .tab, .confidence i').forEach((el) => {
            const b = el.getBoundingClientRect();
            if (!b.width || !b.height || el.closest('.sidebar')) return;
            const min = window.matchMedia('(hover: none)').matches ? 24 : 12;
            if (b.height < min || b.width < min) small.push(`${el.tagName.toLowerCase()}=${Math.round(b.width)}x${Math.round(b.height)}`);
          });
          const thead = document.querySelector('table.data thead');
          return {
            overflow: de.scrollWidth - de.clientWidth,
            small: [...new Set(small)],
            dialogLeak: getComputedStyle(document.querySelector('#modal-root')).display !== 'none',
            nav: getComputedStyle(document.querySelector('#bottom-nav')).display,
            sidebar: getComputedStyle(document.querySelector('.sidebar')).display,
            tableHead: thead ? getComputedStyle(thead).display : 'n/a',
            rendered: !document.querySelector('.empty') || document.body.textContent.length > 200,
          };
        });

        const phone = d.width <= 900;
        const problems = [];
        if (r.overflow > 0) problems.push(`overflow ${r.overflow}px`);
        if (r.small.length) problems.push(`tiny targets: ${r.small.join(', ')}`);
        if (r.dialogLeak) problems.push('dialog overlay visible');
        if (phone && !(r.nav === 'flex' && r.sidebar === 'none')) problems.push('wrong nav shell');
        if (!phone && !(r.nav === 'none' && r.sidebar === 'flex')) problems.push('wrong nav shell');
        const cardMode = d.width <= 700;
        if (view === 'assignments' && cardMode && r.tableHead !== 'none') problems.push('table not collapsed');
        if (view === 'assignments' && !cardMode && r.tableHead === 'none') problems.push('table collapsed too early');
        if (!r.rendered) problems.push('view empty');

        check(problems.length === 0, `${view}`, problems.join('; '));
      }

      // role-specific behaviour
      if (role === 'teacher') {
        await page.goto(`${BASE}/#/assignments`, { waitUntil: 'networkidle' });
        await page.waitForTimeout(400);
        const hasGrading = await page.locator('[data-action="open-submissions"]').count();
        check(hasGrading > 0, 'teacher sees grading controls');

        await page.locator('[data-action="open-submissions"]').first().click();
        await page.waitForTimeout(700);
        const dlg = await page.evaluate(() => {
          const modal = document.querySelector('.modal');
          const form = document.querySelector('#modal-form');
          const row = form.querySelector('.sub-row');
          const input = form.querySelector('input.score-input');
          const save = row.querySelector('[data-action="save-grade"]');
          const ib = input.getBoundingClientRect();
          const rb = row.getBoundingClientRect();
          const sb = save.getBoundingClientRect();
          return {
            students: form.querySelectorAll('.sub-row').length,
            inputW: Math.round(ib.width),
            inputInside: ib.right <= rb.right + 1 && ib.left >= rb.left,
            saveInside: sb.right <= rb.right + 1 && sb.width > 24 && sb.height > 24,
            modalFits: modal.getBoundingClientRect().right <= window.innerWidth + 1 && modal.getBoundingClientRect().left >= -1,
            hasCourse: /CS\d{3}/.test(document.querySelector('#modal-title').textContent + form.textContent),
          };
        });
        check(dlg.students === 3, `grading dialog lists enrolled students (${dlg.students})`);
        check(dlg.inputW >= 55 && dlg.inputW <= 110, 'mark input keeps its size', `${dlg.inputW}px`);
        check(dlg.inputInside && dlg.saveInside, 'mark input and Save stay inside the row');
        check(dlg.modalFits, 'dialog fits the viewport');
        check(dlg.hasCourse, 'dialog names the course');
        await page.keyboard.press('Escape');

        await page.goto(`${BASE}/#/courses`, { waitUntil: 'networkidle' });
        await page.waitForTimeout(400);
        const joinCodes = await page.locator('.join-chip').count();
        check(joinCodes > 0, 'teacher course cards show join codes');
      } else {
        await page.goto(`${BASE}/#/courses`, { waitUntil: 'networkidle' });
        await page.waitForTimeout(400);
        check(await page.locator('[data-action="join-course"]').count() > 0, 'student sees the Join course action');
        check(await page.locator('[data-action="new-course"]').count() === 0, 'student cannot see New course');

        await page.goto(`${BASE}/#/assignments`, { waitUntil: 'networkidle' });
        await page.waitForTimeout(400);
        check(await page.locator('select[data-change="assignment-status"]').count() > 0,
          'student can change assignment status inline');
        check(await page.locator('[data-action="open-submissions"]').count() === 0,
          'student cannot grade');
      }

      check(errors.length === 0, 'no console/page errors', errors.slice(0, 2).join(' | '));
      await ctx.close();
      console.log('');
    }
  }

  await browser.close();
  console.log(failures ? `${failures} check(s) failed` : 'All responsive + role checks passed');
  process.exit(failures ? 1 : 0);
})();
