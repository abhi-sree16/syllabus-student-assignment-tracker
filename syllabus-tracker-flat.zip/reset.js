'use strict';

/** Wipe the database file and re-seed the demo data: `npm run reset` */
const fs = require('fs');
const path = require('path');

const dbFile = process.env.DB_PATH || path.join(__dirname, 'data', 'tracker.db');
for (const suffix of ['', '-wal', '-shm']) {
  const f = dbFile + suffix;
  if (fs.existsSync(f)) {
    fs.unlinkSync(f);
    console.log('removed', f);
  }
}

const { db, migrate, seedIfEmpty } = require('./db');
const { hashPassword } = require('./auth');

migrate();
console.log(seedIfEmpty(hashPassword) ? 'database re-seeded' : 'nothing to seed');

console.log({
  users: db.prepare('SELECT COUNT(*) n FROM users').get().n,
  courses: db.prepare('SELECT COUNT(*) n FROM courses').get().n,
  topics: db.prepare('SELECT COUNT(*) n FROM topics').get().n,
  assignments: db.prepare('SELECT COUNT(*) n FROM assignments').get().n,
  enrolments: db.prepare('SELECT COUNT(*) n FROM enrollments').get().n,
});
db.close();
