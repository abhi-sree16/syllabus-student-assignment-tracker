/* =========================================================================
   Syllabus & Assignment Tracker — front-end (vanilla JS, no build step)
   Two roles: teachers own courses and grade; students track their own progress.
   ========================================================================= */
'use strict';

/* ------------------------------------------------------------------ state */
const state = {
  view: 'dashboard',
  user: null,
  courses: [],
  dashboard: null,
  syllabusCourseId: null,
  filters: { q: '', course_id: '', status: 'open', sort: 'due' },
  filtersOpen: false,
  authMode: 'login',
};

const $ = (sel, root = document) => root.querySelector(sel);
const isTeacher = () => state.user?.role === 'teacher';
const isStudent = () => state.user?.role === 'student';

/* --------------------------------------------------------------- helpers */
const esc = (v) =>
  String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const TOPIC_LABEL = { not_started: 'Not started', in_progress: 'In progress', completed: 'Completed' };
const STATUS_LABEL = { todo: 'To do', in_progress: 'In progress', submitted: 'Submitted', graded: 'Graded', late: 'Late' };
const TYPE_LABEL = {
  homework: 'Homework', quiz: 'Quiz', lab: 'Lab', project: 'Project',
  exam: 'Exam', reading: 'Reading', presentation: 'Presentation',
};
const initials = (name) => String(name || '?').trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('').toUpperCase();

const parseDate = (iso) => {
  const [y, m, d] = String(iso).slice(0, 10).split('-').map(Number);
  return new Date(y, m - 1, d);
};
const todayMidnight = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
const daysBetween = (iso) => Math.round((parseDate(iso) - todayMidnight()) / 864e5);

function fmtDate(iso) {
  return parseDate(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

function dueLabel(iso, status) {
  const n = daysBetween(iso);
  const closed = status === 'submitted' || status === 'graded';
  if (closed) return { text: fmtDate(iso), cls: 'done' };
  if (n < 0) return { text: `${Math.abs(n)} day${Math.abs(n) === 1 ? '' : 's'} overdue`, cls: 'overdue' };
  if (n === 0) return { text: 'Due today', cls: 'overdue' };
  if (n === 1) return { text: 'Due tomorrow', cls: 'soon' };
  if (n <= 7) return { text: `Due in ${n} days`, cls: 'soon' };
  return { text: fmtDate(iso), cls: '' };
}

const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0);

/* -------------------------------------------------------------- transport */
async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    credentials: 'same-origin',
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { error: text }; }

  if (res.status === 401 && state.user) {
    state.user = null;
    renderAuth();
  }
  if (!res.ok) {
    const err = new Error(data?.error || `Request failed (${res.status})`);
    err.status = res.status;
    err.details = data?.details || null;
    throw err;
  }
  return data;
}

/* ----------------------------------------------------------------- toasts */
function toast(message, kind = 'ok') {
  const box = $('#toasts');
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.innerHTML = `<span>${kind === 'ok' ? '✓' : '!'}</span><span>${esc(message)}</span>`;
  box.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .25s ease, transform .25s ease';
    el.style.opacity = '0';
    el.style.transform = 'translateX(12px)';
    setTimeout(() => el.remove(), 260);
  }, 3200);
}

/* ------------------------------------------------------------------ modal */
const modalRoot = () => $('#modal-root');

function closeModal() {
  modalRoot().hidden = true;
  document.body.classList.remove('modal-open');
  const form = $('#modal-form');
  form.innerHTML = '';
  form.onsubmit = null;
  $('#modal-submit').hidden = false;
  $('#modal-foot-cancel').textContent = 'Cancel';
}

/** Read-only / custom-content dialog (rosters, submissions). */
function openCustomModal({ title, html, onSubmit = null, submitLabel = null, cancelLabel = 'Close' }) {
  const root = modalRoot();
  $('#modal-title').textContent = title;
  const form = $('#modal-form');
  form.innerHTML = html;
  form.onsubmit = onSubmit ? async (ev) => { ev.preventDefault(); await onSubmit(); } : (ev) => ev.preventDefault();

  const submit = $('#modal-submit');
  submit.hidden = !submitLabel;
  if (submitLabel) submit.textContent = submitLabel;
  $('#modal-foot-cancel').textContent = cancelLabel;

  root.hidden = false;
  document.body.classList.add('modal-open');
}

/** Open a form dialog. fields: [{name,label,type,options,wide,required,value,hint,...}] */
function openForm({ title, fields, values = {}, submitLabel = 'Save', onSubmit, intro = '' }) {
  const root = modalRoot();
  $('#modal-title').textContent = title;
  $('#modal-submit').textContent = submitLabel;
  $('#modal-submit').hidden = false;
  $('#modal-submit').disabled = false;
  $('#modal-foot-cancel').textContent = 'Cancel';

  const valueOf = (f) => (values[f.name] !== undefined && values[f.name] !== null ? values[f.name] : f.value ?? '');

  const control = (f) => {
    const v = valueOf(f);
    const attrs = [
      `name="${f.name}"`, `id="f-${f.name}"`,
      f.required ? 'required' : '', f.min !== undefined ? `min="${f.min}"` : '',
      f.max !== undefined ? `max="${f.max}"` : '', f.step !== undefined ? `step="${f.step}"` : '',
      f.placeholder ? `placeholder="${esc(f.placeholder)}"` : '',
    ].filter(Boolean).join(' ');

    if (f.type === 'textarea') return `<textarea ${attrs} rows="${f.rows || 3}">${esc(v)}</textarea>`;
    if (f.type === 'select') {
      const opts = (f.options || []).map((o) => {
        const [val, label] = Array.isArray(o) ? o : [o.value ?? o, o.label ?? o];
        return `<option value="${esc(val)}" ${String(val) === String(v) ? 'selected' : ''}>${esc(label)}</option>`;
      }).join('');
      return `<select ${attrs}>${f.emptyOption ? `<option value="">${esc(f.emptyOption)}</option>` : ''}${opts}</select>`;
    }
    if (f.type === 'color') return `<input type="color" ${attrs} value="${esc(v || '#6366f1')}" />`;
    return `<input type="${f.type || 'text'}" ${attrs} value="${esc(v)}" />`;
  };

  $('#modal-form').innerHTML = [
    intro ? `<div class="form-row span-2"><p class="small muted">${esc(intro)}</p></div>` : '',
    ...fields.map((f) => `
      <div class="form-row ${f.wide ? 'span-2' : ''}" data-field="${f.name}">
        <label for="f-${f.name}">${esc(f.label)}${f.required ? ' *' : ''}</label>
        ${control(f)}
        ${f.hint ? `<span class="hint-line">${esc(f.hint)}</span>` : ''}
        <span class="err-msg" data-error="${f.name}" hidden></span>
      </div>`),
  ].join('');

  root.hidden = false;
  document.body.classList.add('modal-open');
  const first = $('#modal-form input, #modal-form select, #modal-form textarea');
  const touch = window.matchMedia('(hover: none)').matches;
  if (first && !touch) {
    const target = $('#modal-form input:not([type="hidden"])');
    if (target) setTimeout(() => target.focus(), 40);
  }

  $('#modal-form').onsubmit = async (ev) => {
    ev.preventDefault();
    const form = ev.currentTarget;
    form.querySelectorAll('.err').forEach((el) => el.classList.remove('err'));
    form.querySelectorAll('[data-error]').forEach((el) => { el.hidden = true; el.textContent = ''; });

    const payload = {};
    for (const f of fields) {
      const el = form.querySelector(`[name="${f.name}"]`);
      if (!el) continue;
      let v = el.value;
      if (typeof v === 'string') v = v.trim();
      if (v === '' && f.type !== 'textarea' && f.type !== 'text') v = null;
      payload[f.name] = v;
    }

    const btn = $('#modal-submit');
    btn.disabled = true;
    try {
      await onSubmit(payload);
      closeModal();
    } catch (err) {
      btn.disabled = false;
      if (err.details) {
        Object.entries(err.details).forEach(([field, msg]) => {
          const holder = form.querySelector(`[data-error="${field}"]`);
          const input = form.querySelector(`[name="${field}"]`);
          if (holder) { holder.textContent = msg; holder.hidden = false; }
          if (input) input.classList.add('err');
        });
      }
      toast(err.message, 'err');
    }
  };
}

/* ------------------------------------------------------------------- data */
async function loadCourses() { state.courses = await api('/api/courses'); }
async function loadDashboard() { state.dashboard = await api('/api/dashboard'); }

async function withRefresh(fn, successMessage) {
  try {
    const result = await fn();
    if (successMessage) toast(successMessage);
    await render();
    return result;
  } catch (err) {
    toast(err.message, 'err');
    throw err;
  }
}

/* ================================================================ auth UI */
function renderAuth() {
  document.body.classList.add('auth-mode');
  document.body.classList.remove('modal-open');
  closeModal();
  const mode = state.authMode;

  const field = (name, label, type, extra = '') => `
    <div class="form-row span-2" data-field="${name}">
      <label for="auth-${name}">${label}</label>
      <input type="${type}" id="auth-${name}" name="${name}" ${extra} autocomplete="${name === 'password' ? 'current-password' : 'on'}" />
      <span class="err-msg" data-error="${name}" hidden></span>
    </div>`;

  $('#view').innerHTML = `
    <div class="auth-wrap">
      <div class="card auth-card">
        <div class="brand auth-brand">
          <span class="brand-mark">S</span>
          <div><strong>Syllabus</strong><span>Assignment Tracker</span></div>
        </div>

        <div class="auth-tabs">
          <button class="tab ${mode === 'login' ? 'active' : ''}" data-action="auth-tab" data-tab="login">Sign in</button>
          <button class="tab ${mode === 'register' ? 'active' : ''}" data-action="auth-tab" data-tab="register">Create account</button>
        </div>

        <form id="auth-form" class="auth-form" novalidate>
          ${mode === 'register' ? field('name', 'Full name', 'text', 'placeholder="Abhi Sree" required') : ''}
          ${field('email', 'Email', 'email', 'placeholder="you@college.edu" required')}
          ${field('password', 'Password', 'password', `placeholder="••••••••" required`)}
          ${mode === 'register' ? `
            <div class="form-row span-2" data-field="role">
              <label for="auth-role">I am a</label>
              <select id="auth-role" name="role">
                <option value="student">Student — track my own progress</option>
                <option value="teacher">Teacher — run courses and grade</option>
              </select>
              <span class="err-msg" data-error="role" hidden></span>
            </div>` : ''}
          <div class="form-row span-2">
            <button class="btn primary full-btn" type="submit" id="auth-submit">
              ${mode === 'login' ? 'Sign in' : 'Create account'}
            </button>
          </div>
        </form>

        ${mode === 'login' ? `
          <div class="demo-box">
            <p class="small faint">Demo accounts — password <code>demo1234</code></p>
            <div class="demo-btns">
              <button class="btn sm ghost" data-action="demo-login" data-email="priya@demo.edu">Teacher: priya@demo.edu</button>
              <button class="btn sm ghost" data-action="demo-login" data-email="abhi@demo.edu">Student: abhi@demo.edu</button>
            </div>
          </div>` : '<p class="small faint auth-note">Teachers create courses and grade. Students join with a 6-character code.</p>'}
      </div>
    </div>`;

  $('#auth-form').onsubmit = async (ev) => {
    ev.preventDefault();
    const form = ev.currentTarget;
    form.querySelectorAll('.err').forEach((el) => el.classList.remove('err'));
    form.querySelectorAll('[data-error]').forEach((el) => { el.hidden = true; el.textContent = ''; });

    const payload = Object.fromEntries(new FormData(form).entries());
    const btn = $('#auth-submit');
    btn.disabled = true;
    btn.textContent = 'Please wait…';
    try {
      const user = await api(`/api/auth/${mode === 'login' ? 'login' : 'register'}`, { method: 'POST', body: payload });
      state.user = user;
      document.body.classList.remove('auth-mode');
      location.hash = '#/dashboard';
      await render();
      toast(`Welcome${mode === 'register' ? '' : ' back'}, ${user.name.split(' ')[0]}`);
    } catch (err) {
      btn.disabled = false;
      btn.textContent = mode === 'login' ? 'Sign in' : 'Create account';
      if (err.details) {
        Object.entries(err.details).forEach(([f, msg]) => {
          const holder = form.querySelector(`[data-error="${f}"]`);
          const input = form.querySelector(`[name="${f}"]`);
          if (holder) { holder.textContent = msg; holder.hidden = false; }
          if (input) input.classList.add('err');
        });
      }
      toast(err.message, 'err');
    }
  };
}

/* ================================================================ chrome */
function renderAccount() {
  if (!state.user) return;
  const footer = $('.sidebar-footer');
  if (footer) {
    footer.innerHTML = `
      <div class="account-mini">
        <span class="avatar">${esc(initials(state.user.name))}</span>
        <div class="account-mini-text">
          <strong>${esc(state.user.name)}</strong>
          <span class="role-badge ${esc(state.user.role)}">${esc(state.user.role)}</span>
        </div>
      </div>
      <div class="account-links">
        <a class="ghost-link" href="/api/export" download>↓ Export</a>
        <button class="ghost-link as-link" data-action="logout">Sign out</button>
      </div>
      <span class="api-state" id="api-state">signed in</span>`;
  }
}

function updateChrome() {
  document.body.classList.toggle('auth-mode', !state.user);
  if (!state.user) {
    $('#page-title').textContent = 'Welcome';
    $('#page-subtitle').textContent = 'Sign in to continue';
    $('#topbar-actions').innerHTML = '';
    return;
  }

  const titles = {
    dashboard: ['Dashboard', isTeacher() ? 'Your classes at a glance' : 'Your semester at a glance'],
    courses: ['Courses', isTeacher() ? 'Courses you run' : 'Courses you are enrolled in'],
    syllabus: ['Syllabus', isTeacher() ? 'Define what the class covers' : 'Tick off what you have covered'],
    assignments: ['Assignments', isTeacher() ? 'Set work and record marks' : 'Everything due, graded and overdue'],
  };
  const [title, sub] = titles[state.view] || titles.dashboard;
  $('#page-title').textContent = title;
  $('#page-subtitle').textContent = sub;

  document.querySelectorAll('#nav a, #bottom-nav a').forEach((a) => {
    a.classList.toggle('active', a.dataset.view === state.view);
  });

  const teacher = isTeacher();
  const actions = {
    dashboard: `<button class="btn ghost" data-action="refresh">↻ Refresh</button>${teacher
      ? '<button class="btn primary" data-action="new-assignment">+ New assignment</button>' : ''}`,
    courses: teacher
      ? '<button class="btn primary" data-action="new-course">+ New course</button>'
      : '<button class="btn primary" data-action="join-course">+ Join course</button>',
    syllabus: teacher
      ? '<button class="btn ghost" data-action="refresh">↻ Refresh</button><button class="btn primary" data-action="new-topic">+ Add topic</button>'
      : '<button class="btn ghost" data-action="refresh">↻ Refresh</button>',
    assignments: teacher ? '<button class="btn primary" data-action="new-assignment">+ New assignment</button>' : '',
  };
  $('#topbar-actions').innerHTML = actions[state.view] || '';
  renderAccount();
}

const emptyState = (emoji, title, body, actionHtml = '') => `
  <div class="card empty">
    <div class="emoji">${emoji}</div>
    <h3>${esc(title)}</h3>
    <p>${esc(body)}</p>
    ${actionHtml}
  </div>`;

const accountStrip = () => `
  <div class="card account-strip">
    <span class="avatar">${esc(initials(state.user.name))}</span>
    <div class="account-mini-text">
      <strong>${esc(state.user.name)}</strong>
      <span class="role-badge ${esc(state.user.role)}">${esc(state.user.role)}</span>
    </div>
    <button class="btn sm ghost" data-action="logout">Sign out</button>
  </div>`;

/* ------------------------------------------------------------- dashboard */
async function renderDashboard(view) {
  await loadDashboard();
  const d = state.dashboard;
  const s = d.summary;

  if (isTeacher()) {
    const kpis = `
      <div class="grid cols-4">
        <div class="card kpi">
          <div class="label">Students</div>
          <div class="value">${s.students}</div>
          <div class="hint">across ${s.courses} course${s.courses === 1 ? '' : 's'}</div>
        </div>
        <div class="card kpi ${s.to_grade ? 'warn' : 'good'}">
          <div class="label">Waiting to grade</div>
          <div class="value">${s.to_grade}</div>
          <div class="hint">${s.to_grade ? 'submissions handed in' : 'all caught up'}</div>
        </div>
        <div class="card kpi">
          <div class="label">Due this week</div>
          <div class="value">${s.due_this_week}</div>
          <div class="hint">${s.assignments} assignments set</div>
        </div>
        <div class="card kpi ${s.average_percent === null ? '' : s.average_percent >= 75 ? 'good' : 'warn'}">
          <div class="label">Class average</div>
          <div class="value">${s.average_percent === null ? '—' : `${s.average_percent}<small>%</small>`}</div>
          <div class="hint">${s.graded_count} marks recorded</div>
        </div>
      </div>`;

    const courseCards = d.courses.length
      ? d.courses.map((c) => `
        <div class="card course-progress">
          <div class="head">
            <span class="dot" style="background:${esc(c.color)}"></span>
            <strong>${esc(c.code)}</strong>
            <span class="small faint">${esc(c.name)}</span>
            <span class="pct">${c.progress}%</span>
          </div>
          <div class="bar"><i style="width:${c.progress}%;background:${esc(c.color)}"></i></div>
          <div class="small muted">
            ${c.student_count} student${c.student_count === 1 ? '' : 's'} · ${c.topic_count} topics
            ${c.to_grade ? ` · <span style="color:#fcd34d">${c.to_grade} to grade</span>` : ''}
          </div>
        </div>`).join('')
      : emptyState('📚', 'No courses yet', 'Create your first course, then share its join code with the class.',
        '<button class="btn primary" data-action="new-course">+ New course</button>');

    const pending = d.pending.length
      ? `<div class="card list">${d.pending.map((p) => `
          <div class="list-row">
            <span class="avatar sm">${esc(initials(p.student_name))}</span>
            <div class="grow">
              <div class="title">${esc(p.student_name)}</div>
              <div class="sub"><span>${esc(p.course_code)}</span><span>${esc(p.title)}</span></div>
            </div>
            <button class="btn sm" data-action="open-submissions" data-id="${p.assignment_id}">Grade</button>
          </div>`).join('')}</div>`
      : emptyState('✅', 'Nothing waiting', 'No submissions are pending grading right now.');

    const upcoming = d.upcoming.length
      ? `<div class="card list">${d.upcoming.map((a) => {
        const due = dueLabel(a.due_date, 'todo');
        return `
          <div class="list-row">
            <span class="dot" style="background:${esc(a.course_color)}"></span>
            <div class="grow">
              <div class="title">${esc(a.title)}</div>
              <div class="sub">
                <span>${esc(a.course_code)}</span>
                <span class="pill chip">${esc(TYPE_LABEL[a.type] || a.type)}</span>
                <span>${a.submitted_count}/${a.student_count} submitted</span>
              </div>
            </div>
            <span class="due ${due.cls}">${due.text}</span>
          </div>`;
      }).join('')}</div>`
      : emptyState('🗓️', 'No upcoming deadlines', 'Set an assignment and it will show here.');

    view.innerHTML = `
      ${accountStrip()}
      ${kpis}
      <div class="section-title">Class progress <span class="spacer"></span>
        <button class="btn sm ghost" data-action="go" data-view="courses">All courses →</button>
      </div>
      <div class="grid cols-2">${courseCards}</div>
      <div class="section-title">Waiting to be graded</div>
      ${pending}
      <div class="section-title">Coming up <span class="spacer"></span>
        <button class="btn sm ghost" data-action="go" data-view="assignments">All assignments →</button>
      </div>
      ${upcoming}`;
    return;
  }

  /* ------------------------------------------------------------- student */
  const kpis = `
    <div class="grid cols-4">
      <div class="card kpi">
        <div class="kpi-row">
          <div>
            <div class="label">Syllabus covered</div>
            <div class="value">${s.syllabus_progress}<small>%</small></div>
            <div class="hint">${s.topics_completed} of ${s.topics} topics</div>
          </div>
          <div class="ring" style="--pct:${s.syllabus_progress}"><span>${s.syllabus_progress}%</span></div>
        </div>
      </div>
      <div class="card kpi">
        <div class="label">Open assignments</div>
        <div class="value">${s.open_assignments}</div>
        <div class="hint">${s.due_this_week} due within 7 days</div>
      </div>
      <div class="card kpi ${s.overdue_assignments ? 'bad' : 'good'}">
        <div class="label">Overdue</div>
        <div class="value">${s.overdue_assignments}</div>
        <div class="hint">${s.overdue_assignments ? 'Clear these first' : 'Nothing overdue — nice'}</div>
      </div>
      <div class="card kpi ${s.average_percent === null ? '' : s.average_percent >= 75 ? 'good' : 'warn'}">
        <div class="label">Average score</div>
        <div class="value">${s.average_percent === null ? '—' : `${s.average_percent}<small>%</small>`}</div>
        <div class="hint">${s.graded_count} graded · ${s.submitted} awaiting mark</div>
      </div>
    </div>`;

  const courseCards = d.courses.length
    ? d.courses.map((c) => `
      <div class="card course-progress">
        <div class="head">
          <span class="dot" style="background:${esc(c.color)}"></span>
          <strong>${esc(c.code)}</strong>
          <span class="small faint">${esc(c.name)}</span>
          <span class="pct">${c.progress}%</span>
        </div>
        <div class="bar"><i style="width:${c.progress}%;background:${esc(c.color)}"></i></div>
        <div class="small muted">
          ${c.topics_completed}/${c.topic_count} topics · ${c.topics_in_progress} in progress
          · ${esc(c.teacher_name)}
        </div>
      </div>`).join('')
    : emptyState('🎓', 'No courses yet', 'Ask your teacher for a join code, then add the course.',
      '<button class="btn primary" data-action="join-course">+ Join course</button>');

  const upcoming = d.upcoming.length
    ? `<div class="card list">${d.upcoming.map((a) => {
      const due = dueLabel(a.due_date, a.status);
      return `
        <div class="list-row">
          <span class="dot" style="background:${esc(a.course_color)}"></span>
          <div class="grow">
            <div class="title">${esc(a.title)}</div>
            <div class="sub">
              <span>${esc(a.course_code)}</span>
              <span class="pill chip">${esc(TYPE_LABEL[a.type] || a.type)}</span>
              <span class="pill ${esc(a.priority)}">${esc(a.priority)}</span>
            </div>
          </div>
          <span class="due ${due.cls}">${due.text}</span>
          <button class="btn sm ghost" data-action="advance-assignment" data-id="${a.id}"
                  title="Move this assignment forward">→</button>
        </div>`;
    }).join('')}</div>`
    : emptyState('🎉', 'Nothing due', 'No open assignments right now.');

  view.innerHTML = `
    ${accountStrip()}
    ${kpis}
    <div class="section-title">Course progress <span class="spacer"></span>
      <button class="btn sm ghost" data-action="go" data-view="syllabus">Open syllabus →</button>
    </div>
    <div class="grid cols-2">${courseCards}</div>
    <div class="section-title">Next up <span class="spacer"></span>
      <button class="btn sm ghost" data-action="go" data-view="assignments">All assignments →</button>
    </div>
    ${upcoming}
    <div class="small faint footer-note">
      ${s.courses} courses · ${s.credits} credits · ${s.study_hours} syllabus hours tracked
    </div>`;
}

/* ---------------------------------------------------------------- courses */
async function renderCourses(view) {
  await loadCourses();
  const teacher = isTeacher();

  const cards = state.courses.length
    ? `<div class="course-grid">${state.courses.map((c) => `
        <div class="card course-card" style="--c:${esc(c.color)}">
          <div style="display:flex;align-items:center;gap:9px;flex-wrap:wrap">
            <span class="code">${esc(c.code)}</span>
            <span class="small faint">${esc(c.semester || '')}</span>
          </div>
          <h3>${esc(c.name)}</h3>
          <div class="meta">
            ${teacher
              ? `<span>👥 ${c.student_count} student${c.student_count === 1 ? '' : 's'}</span>`
              : `<span>👤 ${esc(c.teacher_name || c.instructor || 'Teacher')}</span>`}
            <span>🎓 ${c.credits} credits</span>
          </div>
          ${teacher ? `<div class="join-chip">Join code <strong>${esc(c.join_code)}</strong></div>` : ''}
          <div class="bar"><i style="width:${c.progress}%;background:${esc(c.color)}"></i></div>
          <div class="small muted">
            ${teacher
              ? `${c.topic_count} topics · ${c.assignment_count} assignments · ${c.progress}% class coverage`
              : `${c.topics_completed}/${c.topic_count} topics completed${c.open_assignments ? ` · ${c.open_assignments} open` : ''}${c.overdue_assignments ? ` · <span style="color:#fb7185">${c.overdue_assignments} overdue</span>` : ''}`}
          </div>
          <div class="foot">
            <button class="btn sm" data-action="open-syllabus" data-id="${c.id}">Syllabus</button>
            ${teacher
              ? `<button class="btn sm ghost" data-action="open-roster" data-id="${c.id}">Roster</button>
                 <button class="icon-btn" data-action="edit-course" data-id="${c.id}" title="Edit course">✎</button>
                 <button class="icon-btn" data-action="delete-course" data-id="${c.id}" title="Delete course">✕</button>`
              : ''}
            <span class="pct">${c.progress}%</span>
          </div>
        </div>`).join('')}</div>`
    : emptyState(teacher ? '🗂️' : '🎓',
      teacher ? 'No courses yet' : 'Not enrolled yet',
      teacher
        ? 'Create a course with its code, instructor and credits — a join code is generated for your class.'
        : 'Ask your teacher for the 6-character join code, then add the course here.',
      teacher
        ? '<button class="btn primary" data-action="new-course">+ New course</button>'
        : '<button class="btn primary" data-action="join-course">+ Join course</button>');

  view.innerHTML = cards;
}

/* --------------------------------------------------------------- syllabus */
async function renderSyllabus(view) {
  await loadCourses();
  const teacher = isTeacher();

  if (!state.courses.length) {
    view.innerHTML = emptyState('📖', 'No syllabus to show',
      teacher ? 'Create a course first, then break the syllabus into units and topics.'
        : 'Join a course to see its syllabus.',
      teacher
        ? '<button class="btn primary" data-action="new-course">+ New course</button>'
        : '<button class="btn primary" data-action="join-course">+ Join course</button>');
    return;
  }

  if (!state.syllabusCourseId || !state.courses.some((c) => c.id === state.syllabusCourseId)) {
    state.syllabusCourseId = state.courses[0].id;
  }

  const course = await api(`/api/courses/${state.syllabusCourseId}`);
  const topics = course.topics || [];
  const done = teacher
    ? topics.filter((t) => t.class_completed > 0).length
    : topics.filter((t) => t.status === 'completed').length;
  const progress = teacher ? course.progress : pct(done, topics.length);

  const units = [...new Set(topics.map((t) => t.unit || 'Unit 1'))];
  const groups = units.map((unit) => ({ unit, items: topics.filter((t) => (t.unit || 'Unit 1') === unit) }));

  const tabs = state.courses.map((c) => `
    <button class="tab ${c.id === state.syllabusCourseId ? 'active' : ''}"
            data-action="select-course" data-id="${c.id}">${esc(c.code)}</button>`).join('');

  const header = `
    <div class="card course-hero">
      <div class="course-hero-row">
        <span class="dot" style="background:${esc(course.color)};width:11px;height:11px;margin-top:6px"></span>
        <div class="course-hero-main">
          <h2>${esc(course.name)}</h2>
          <p class="small muted">
            ${esc(course.code)} · ${esc(course.instructor || 'No instructor')} · ${course.credits} credits
            ${teacher ? ` · join code <strong>${esc(course.join_code)}</strong>` : ''}
          </p>
        </div>
        <div class="course-hero-stat">
          <span class="stat">${progress}%</span>
          <span class="small muted">${teacher
            ? `${topics.length} topics · ${course.student_count || 0} students`
            : `${done}/${topics.length} topics · ${course.syllabus_hours}h`}</span>
        </div>
      </div>
      <div class="bar"><i style="width:${progress}%;background:${esc(course.color)}"></i></div>
    </div>`;

  const topicRows = groups.map(({ unit, items }) => {
    const unitDone = teacher
      ? items.filter((t) => t.class_completed > 0).length
      : items.filter((t) => t.status === 'completed').length;
    return `
      <div class="card unit-block">
        <div class="unit-head">
          <span>${esc(unit)}</span>
          <span class="spacer"></span>
          <span class="faint">${unitDone}/${items.length}</span>
          ${teacher ? `<button class="btn sm ghost" data-action="new-topic" data-unit="${esc(unit)}">+ topic</button>` : ''}
        </div>
        ${items.map((t) => (teacher ? `
          <div class="topic-row">
            <div class="grow">
              <div class="title">${esc(t.title)}</div>
              ${t.description ? `<div class="desc">${esc(t.description)}</div>` : ''}
            </div>
            <span class="pill chip" title="Students who completed this topic">
              ${t.class_completed}/${t.student_count} completed
            </span>
            <span class="small faint mono">${t.est_hours}h</span>
            <div class="topic-actions">
              <button class="icon-btn" data-action="edit-topic" data-id="${t.id}" title="Edit topic">✎</button>
              <button class="icon-btn" data-action="delete-topic" data-id="${t.id}" title="Delete topic">✕</button>
            </div>
          </div>` : `
          <div class="topic-row ${t.status === 'completed' ? 'done' : ''}">
            <button class="status-btn ${esc(t.status)}" data-action="cycle-topic" data-id="${t.id}"
                    title="Tap to change your status">
              <span class="mark"></span>${TOPIC_LABEL[t.status]}
            </button>
            <div class="grow">
              <div class="title">${esc(t.title)}</div>
              ${t.description ? `<div class="desc">${esc(t.description)}</div>` : ''}
            </div>
            <span class="est small faint mono" title="Estimated hours">${t.est_hours}h</span>
            <span class="confidence" title="Your confidence ${t.confidence}/5">
              ${[1, 2, 3, 4, 5].map((i) => `<i class="${i <= t.confidence ? 'on' : ''}"
                 data-action="set-confidence" data-id="${t.id}" data-value="${i}"></i>`).join('')}
            </span>
          </div>`)).join('')}
      </div>`;
  }).join('');

  view.innerHTML = `
    <div class="tabs">${tabs}</div>
    ${header}
    ${topics.length ? topicRows : emptyState('🧩', 'Empty syllabus',
      teacher ? 'Add units and topics so the class knows what to cover.' : 'Your teacher has not added topics yet.',
      teacher ? '<button class="btn primary" data-action="new-topic">+ Add topic</button>' : '')}`;
}

/* ------------------------------------------------------------ assignments */
async function renderAssignments(view) {
  await loadCourses();
  const teacher = isTeacher();
  const f = state.filters;
  const params = new URLSearchParams();
  if (f.q) params.set('q', f.q);
  if (f.course_id) params.set('course_id', f.course_id);
  if (f.status && !teacher) params.set('status', f.status);
  params.set('sort', f.sort);

  const rows = await api(`/api/assignments?${params.toString()}`);

  const courseOptions = state.courses.map((c) => `
    <option value="${c.id}" ${String(f.course_id) === String(c.id) ? 'selected' : ''}>${esc(c.code)} — ${esc(c.name)}</option>`).join('');

  const statusOptions = [
    ['open', 'Open only'], ['overdue', 'Overdue'], ['', 'All statuses'],
    ['todo', 'To do'], ['in_progress', 'In progress'], ['submitted', 'Submitted'], ['graded', 'Graded'], ['late', 'Late'],
  ].map(([v, l]) => `<option value="${v}" ${f.status === v ? 'selected' : ''}>${l}</option>`).join('');

  const sortOptions = [['due', 'Due date'], ['priority', 'Priority'], ['course', 'Course'], ['created', 'Newest']]
    .map(([v, l]) => `<option value="${v}" ${f.sort === v ? 'selected' : ''}>Sort: ${l}</option>`).join('');

  const studentSelect = (a) => `
    <select class="mini" data-change="assignment-status" data-id="${a.id}">
      ${['todo', 'in_progress', 'submitted'].map((v) =>
        `<option value="${v}" ${a.status === v ? 'selected' : ''}>${STATUS_LABEL[v]}</option>`).join('')}
      ${a.status === 'graded' ? `<option value="graded" selected disabled>Graded</option>` : ''}
      ${a.status === 'late' ? `<option value="late" selected disabled>Late</option>` : ''}
    </select>`;

  const table = rows.length
    ? `<div class="card table-wrap">
        <table class="data">
          <thead>
            <tr>
              <th>Assignment</th><th>Due</th><th>Priority</th>
              <th>${teacher ? 'Submissions' : 'Status'}</th>
              <th>${teacher ? 'Graded' : 'Score'}</th><th></th>
            </tr>
          </thead>
          <tbody>
            ${rows.map((a) => {
              const due = dueLabel(a.due_date, teacher ? 'todo' : a.status);
              const closed = !teacher && (a.status === 'submitted' || a.status === 'graded');
              const dueSub = closed ? '' : `<span class="cell-sub">${fmtDate(a.due_date)}</span>`;
              const grade = teacher
                ? `<span class="mono">${a.graded_count}<span class="faint">/${a.student_count}</span></span>`
                : (a.score === null ? '<span class="faint">—</span>'
                  : `<span class="mono">${a.score}<span class="faint">/${a.max_marks}</span></span>`);

              return `
                <tr>
                  <td class="cell-main">
                    <div class="cell-title">${esc(a.title)}</div>
                    <div class="cell-sub">
                      <span class="dot" style="display:inline-block;background:${esc(a.course_color)};margin-right:5px"></span>
                      ${esc(a.course_code)} · ${esc(TYPE_LABEL[a.type] || a.type)}
                    </div>
                  </td>
                  <td data-label="Due"><div class="cell-stack">
                      <span class="due ${due.cls}">${due.text}</span>${dueSub}
                  </div></td>
                  <td data-label="Priority"><span class="pill ${esc(a.priority)}">${esc(a.priority)}</span></td>
                  <td data-label="${teacher ? 'Submissions' : 'Status'}">
                    ${teacher
                      ? `<span class="pill chip">${a.submitted_count}/${a.student_count} in</span>`
                      : studentSelect(a)}
                  </td>
                  <td data-label="${teacher ? 'Graded' : 'Score'}">${grade}</td>
                  <td class="cell-actions">
                    <div class="row-actions">
                      ${teacher
                        ? `<button class="btn sm" data-action="open-submissions" data-id="${a.id}">Submissions</button>
                           <button class="icon-btn" data-action="edit-assignment" data-id="${a.id}" title="Edit">✎</button>
                           <button class="icon-btn" data-action="delete-assignment" data-id="${a.id}" title="Delete">✕</button>`
                        : `<button class="btn sm ghost" data-action="edit-notes" data-id="${a.id}">Notes</button>`}
                    </div>
                  </td>
                </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>`
    : emptyState('🔍', 'No assignments match', 'Try clearing the filters, or add a new assignment.',
      teacher ? '<button class="btn primary" data-action="new-assignment">+ New assignment</button>' : '');

  const activeFilters = [f.course_id, f.q, (!teacher && f.status !== 'open') ? f.status : ''].filter(Boolean).length;

  view.innerHTML = `
    <div class="toolbar ${state.filtersOpen ? 'open' : ''}">
      <div class="field-inline grow">
        <svg viewBox="0 0 24 24"><path d="M10 2a8 8 0 1 1-5.3 14L1.4 19.3l1.4 1.4 3.3-3.3A8 8 0 0 1 10 2zm0 2a6 6 0 1 0 0 12A6 6 0 0 0 10 4z"/></svg>
        <input type="text" id="search" placeholder="Search assignments…" value="${esc(f.q)}" />
      </div>
      <button class="btn ghost filter-toggle" data-action="toggle-filters" aria-expanded="${state.filtersOpen}">
        Filters${activeFilters ? ` · ${activeFilters}` : ''}
      </button>
      <div class="field-inline filter-select">
        <select id="filter-course" aria-label="Filter by course">
          <option value="">All courses</option>${courseOptions}
        </select>
      </div>
      ${teacher ? '' : `<div class="field-inline filter-select"><select id="filter-status" aria-label="Filter by status">${statusOptions}</select></div>`}
      <div class="field-inline filter-select"><select id="filter-sort" aria-label="Sort assignments">${sortOptions}</select></div>
    </div>
    <div class="small faint" style="margin-bottom:10px">${rows.length} assignment${rows.length === 1 ? '' : 's'}</div>
    ${table}`;
}

/* ================================================================ router */
async function render() {
  if (!state.user) { renderAuth(); return; }

  const view = $('#view');
  const hash = location.hash.replace(/^#\/?/, '');
  state.view = hash.split('/')[0] || 'dashboard';
  if (!['dashboard', 'courses', 'syllabus', 'assignments'].includes(state.view)) state.view = 'dashboard';

  if (state.view === 'syllabus' && hash.split('/')[1]) {
    state.syllabusCourseId = Number(hash.split('/')[1]) || state.syllabusCourseId;
  }

  updateChrome();

  try {
    if (state.view === 'dashboard') await renderDashboard(view);
    else if (state.view === 'courses') await renderCourses(view);
    else if (state.view === 'syllabus') await renderSyllabus(view);
    else await renderAssignments(view);
  } catch (err) {
    if (err.status === 401) return;
    view.innerHTML = emptyState('⚠️', 'Could not load this view', err.message,
      '<button class="btn" data-action="refresh">Try again</button>');
  }
  window.scrollTo({ top: 0 });
}

/* ================================================================== forms */
function courseForm(course = null) {
  openForm({
    title: course ? 'Edit course' : 'New course',
    submitLabel: course ? 'Save changes' : 'Create course',
    values: course || { credits: 3, color: '#6366f1', semester: 'Semester 5' },
    intro: course ? '' : 'A 6-character join code is generated automatically — share it with your class.',
    fields: [
      { name: 'code', label: 'Course code', required: true, placeholder: 'CS301' },
      { name: 'name', label: 'Course name', required: true, placeholder: 'Data Structures & Algorithms' },
      { name: 'instructor', label: 'Instructor', placeholder: 'Dr. R. Prasad' },
      { name: 'semester', label: 'Semester', placeholder: 'Semester 5' },
      { name: 'credits', label: 'Credits', type: 'number', min: 0, max: 12, value: 3 },
      { name: 'color', label: 'Colour', type: 'color', value: '#6366f1' },
    ],
    onSubmit: async (values) => {
      if (course) await api(`/api/courses/${course.id}`, { method: 'PATCH', body: values });
      else await api('/api/courses', { method: 'POST', body: values });
      await loadCourses();
      toast(course ? 'Course updated' : 'Course created');
    },
  });
}

function joinCourseForm() {
  openForm({
    title: 'Join a course',
    submitLabel: 'Join',
    intro: 'Your teacher will give you a 6-character join code.',
    fields: [{
      name: 'code', label: 'Join code', required: true, placeholder: 'ABC123', wide: true,
      hint: 'Letters and numbers, e.g. K7M2QP',
    }],
    onSubmit: async ({ code }) => {
      const course = await api('/api/courses/join', { method: 'POST', body: { code: String(code).toUpperCase() } });
      await loadCourses();
      toast(`Joined ${course.code}`);
    },
  });
}

function topicForm(topic = null, defaults = {}) {
  const courseId = topic?.course_id ?? defaults.course_id ?? state.syllabusCourseId ?? state.courses[0]?.id;
  if (!courseId) { toast('Create a course first', 'err'); return; }

  openForm({
    title: topic ? 'Edit topic' : 'Add syllabus topic',
    submitLabel: topic ? 'Save changes' : 'Add topic',
    values: topic || { unit: defaults.unit || 'Unit 1', est_hours: 2 },
    fields: [
      { name: 'unit', label: 'Unit', placeholder: 'Unit 1', hint: 'New unit names create new groups.' },
      { name: 'est_hours', label: 'Estimated hours', type: 'number', min: 0, step: 0.5, value: 2 },
      { name: 'title', label: 'Topic title', required: true, wide: true, placeholder: 'Trees & Binary Search Trees' },
      { name: 'description', label: 'Notes', type: 'textarea', wide: true, placeholder: 'What this topic covers…' },
    ],
    onSubmit: async (values) => {
      const body = { ...values, est_hours: Number(values.est_hours || 0), unit: values.unit || 'Unit 1' };
      if (topic) await api(`/api/topics/${topic.id}`, { method: 'PATCH', body });
      else await api('/api/topics', { method: 'POST', body: { ...body, course_id: courseId } });
      await loadCourses();
      toast(topic ? 'Topic updated' : 'Topic added');
    },
  });
}

async function assignmentForm(assignment = null, defaults = {}) {
  if (!state.courses.length) { toast('Create a course first', 'err'); return; }
  const courseId = assignment?.course_id ?? defaults.course_id ?? state.syllabusCourseId ?? state.courses[0].id;
  let topics = [];
  try { topics = await api(`/api/topics?course_id=${courseId}`); } catch { topics = []; }

  openForm({
    title: assignment ? 'Edit assignment' : 'New assignment',
    submitLabel: assignment ? 'Save changes' : 'Create assignment',
    values: assignment || {
      course_id: courseId, type: 'homework', priority: 'medium', max_marks: 100,
      due_date: new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10),
    },
    fields: [
      { name: 'title', label: 'Assignment title', required: true, wide: true, placeholder: 'AVL Tree Implementation' },
      { name: 'course_id', label: 'Course', type: 'select', required: true,
        options: state.courses.map((c) => [c.id, `${c.code} — ${c.name}`]) },
      { name: 'topic_id', label: 'Linked syllabus topic', type: 'select', emptyOption: '— none —',
        options: topics.map((t) => [t.id, `${t.unit}: ${t.title}`]) },
      { name: 'type', label: 'Type', type: 'select', options: Object.entries(TYPE_LABEL).map(([v, l]) => [v, l]) },
      { name: 'due_date', label: 'Due date', type: 'date', required: true },
      { name: 'priority', label: 'Priority', type: 'select',
        options: [['low', 'Low'], ['medium', 'Medium'], ['high', 'High']] },
      { name: 'max_marks', label: 'Max marks', type: 'number', min: 1, value: 100 },
      { name: 'description', label: 'Description', type: 'textarea', wide: true, placeholder: 'What needs to be submitted…' },
    ],
    onSubmit: async (values) => {
      const body = {
        ...values,
        course_id: Number(values.course_id),
        topic_id: values.topic_id ? Number(values.topic_id) : null,
        max_marks: Number(values.max_marks || 100),
      };
      if (assignment) await api(`/api/assignments/${assignment.id}`, { method: 'PATCH', body });
      else await api('/api/assignments', { method: 'POST', body });
      await loadCourses();
      toast(assignment ? 'Assignment updated' : 'Assignment created');
    },
  });
}

function notesForm(assignment) {
  openForm({
    title: `Notes · ${assignment.title}`,
    submitLabel: 'Save notes',
    values: { notes: assignment.notes || '' },
    fields: [{ name: 'notes', label: 'Your notes', type: 'textarea', wide: true, rows: 5,
      placeholder: 'Doubts, resources, submission link…' }],
    onSubmit: async ({ notes }) => {
      await api(`/api/assignments/${assignment.id}/progress`, { method: 'PATCH', body: { notes: notes || '' } });
      toast('Notes saved');
    },
  });
}

/* ------------------------------------------------------- teacher dialogs */
async function openRoster(courseId) {
  const data = await api(`/api/courses/${courseId}/roster`);
  const rows = data.students.length
    ? data.students.map((s) => `
        <div class="roster-row">
          <span class="avatar sm">${esc(initials(s.name))}</span>
          <div class="grow">
            <div class="title">${esc(s.name)}</div>
            <div class="small faint">${esc(s.email)}</div>
            <div class="bar tiny"><i style="width:${s.progress}%"></i></div>
          </div>
          <div class="roster-stats">
            <strong>${s.progress}%</strong>
            <span class="small faint">${s.topics_completed}/${s.topic_count} topics</span>
            <span class="small faint">${s.submitted_count} to grade${s.average_percent === null ? '' : ` · ${s.average_percent}% avg`}</span>
          </div>
        </div>`).join('')
    : '<p class="small muted" style="padding:8px 0">No students have joined yet. Share the join code below.</p>';

  openCustomModal({
    title: `Roster · ${data.course.code}`,
    html: `
      <div class="span-2 join-banner">
        Join code <strong>${esc(data.course.join_code)}</strong>
        <span class="small faint">share this with your class</span>
      </div>
      <div class="span-2 roster-list">${rows}</div>`,
  });
}

async function openSubmissions(assignmentId) {
  const data = await api(`/api/assignments/${assignmentId}/submissions`);
  const a = data.assignment;
  const rows = data.students.length
    ? data.students.map((s) => `
        <div class="sub-row" data-student="${s.id}">
          <span class="avatar sm">${esc(initials(s.name))}</span>
          <div class="grow">
            <div class="title">${esc(s.name)}</div>
            <div class="sub">
              <span class="pill ${esc(s.status)}">${esc(STATUS_LABEL[s.status] || s.status)}</span>
              ${s.notes ? `<span class="small faint">“${esc(s.notes)}”</span>` : ''}
            </div>
          </div>
          <input class="score-input" type="number" min="0" max="${a.max_marks}" step="0.5"
                 value="${s.score ?? ''}" placeholder="—" aria-label="Score for ${esc(s.name)}" />
          <button class="btn sm" data-action="save-grade" data-assignment="${a.id}" data-student="${s.id}">Save</button>
        </div>`).join('')
    : '<p class="small muted" style="padding:8px 0">No students are enrolled in this course yet.</p>';

  openCustomModal({
    title: `${a.title} · out of ${a.max_marks}`,
    html: `
      <div class="span-2 small muted">${esc(a.course_code || '')} · due ${fmtDate(a.due_date)} — enter a mark and tap Save.</div>
      <div class="span-2 roster-list">${rows}</div>`,
  });
}

/* ================================================================ actions */
const NEXT_TOPIC_STATUS = { not_started: 'in_progress', in_progress: 'completed', completed: 'not_started' };
const NEXT_ASSIGNMENT_STATUS = { todo: 'in_progress', in_progress: 'submitted', submitted: 'graded', late: 'submitted' };

async function handleAction(action, el) {
  const id = Number(el.dataset.id);

  switch (action) {
    case 'auth-tab':
      state.authMode = el.dataset.tab;
      renderAuth();
      break;

    case 'demo-login': {
      const email = el.dataset.email;
      const form = $('#auth-form');
      if (!form) break;
      form.querySelector('[name="email"]').value = email;
      form.querySelector('[name="password"]').value = 'demo1234';
      form.requestSubmit();
      break;
    }

    case 'logout':
      try { await api('/api/auth/logout', { method: 'POST' }); } catch { /* ignore */ }
      state.user = null;
      state.courses = [];
      state.syllabusCourseId = null;
      location.hash = '';
      renderAuth();
      toast('Signed out');
      break;

    case 'refresh':
      await render();
      toast('Refreshed');
      break;

    case 'go':
      location.hash = `#/${el.dataset.view}`;
      break;

    case 'toggle-filters':
      state.filtersOpen = !state.filtersOpen;
      await renderAssignments($('#view'));
      break;

    case 'select-course':
      state.syllabusCourseId = id;
      await render();
      break;

    case 'open-syllabus':
      state.syllabusCourseId = id;
      location.hash = `#/syllabus/${id}`;
      await render();
      break;

    /* ---------------------------------------------------------- courses */
    case 'new-course':
      courseForm();
      break;

    case 'join-course':
      joinCourseForm();
      break;

    case 'edit-course': {
      const course = state.courses.find((c) => c.id === id);
      if (course) courseForm(course);
      break;
    }

    case 'delete-course': {
      const course = state.courses.find((c) => c.id === id);
      if (!course) break;
      if (!confirm(`Delete ${course.code}? Its topics, assignments and student progress will be removed.`)) break;
      await withRefresh(() => api(`/api/courses/${id}`, { method: 'DELETE' }), 'Course deleted');
      break;
    }

    case 'open-roster':
      await openRoster(id);
      break;

    /* ----------------------------------------------------------- topics */
    case 'new-topic':
      topicForm(null, { unit: el.dataset.unit || 'Unit 1' });
      break;

    case 'edit-topic': {
      if (!state.syllabusCourseId) break;
      const detail = await api(`/api/courses/${state.syllabusCourseId}`);
      const topic = detail.topics.find((t) => t.id === id);
      if (topic) topicForm(topic);
      break;
    }

    case 'cycle-topic': {
      const current = [...el.classList].find((c) => c in NEXT_TOPIC_STATUS);
      const next = NEXT_TOPIC_STATUS[current] || 'in_progress';
      await withRefresh(
        () => api(`/api/topics/${id}/progress`, { method: 'PATCH', body: { status: next } }),
        `Marked ${TOPIC_LABEL[next].toLowerCase()}`
      );
      break;
    }

    case 'set-confidence': {
      const value = Number(el.dataset.value);
      await api(`/api/topics/${id}/progress`, { method: 'PATCH', body: { confidence: value } })
        .catch((e) => toast(e.message, 'err'));
      await render();
      break;
    }

    case 'delete-topic':
      if (!confirm('Delete this topic? Student progress for it will be removed too.')) break;
      await withRefresh(() => api(`/api/topics/${id}`, { method: 'DELETE' }), 'Topic deleted');
      break;

    /* ------------------------------------------------------ assignments */
    case 'new-assignment':
      await assignmentForm(null, { course_id: state.syllabusCourseId });
      break;

    case 'edit-assignment': {
      const assignment = await api(`/api/assignments/${id}`);
      await assignmentForm(assignment);
      break;
    }

    case 'edit-notes': {
      const assignment = await api(`/api/assignments/${id}`);
      notesForm(assignment);
      break;
    }

    case 'open-submissions':
      await openSubmissions(id);
      break;

    case 'save-grade': {
      const studentId = Number(el.dataset.student);
      const row = el.closest('.sub-row');
      const score = row?.querySelector('.score-input')?.value;
      if (score === '' || score === null) { toast('Enter a score first', 'err'); break; }
      try {
        await api(`/api/assignments/${el.dataset.assignment}/grade`, {
          method: 'PATCH', body: { student_id: studentId, score: Number(score) },
        });
        toast('Mark saved');
        await openSubmissions(Number(el.dataset.assignment)); // refresh the dialog
        loadCourses().catch(() => {});
      } catch (err) {
        toast(err.message, 'err');
      }
      break;
    }

    case 'advance-assignment': {
      const assignment = await api(`/api/assignments/${id}`);
      const next = NEXT_ASSIGNMENT_STATUS[assignment.status] || 'submitted';
      await withRefresh(
        () => api(`/api/assignments/${id}/progress`, { method: 'PATCH', body: { status: next } }),
        `${assignment.title} → ${STATUS_LABEL[next]}`
      );
      break;
    }

    case 'delete-assignment':
      if (!confirm('Delete this assignment? Student submissions will be removed too.')) break;
      await withRefresh(() => api(`/api/assignments/${id}`, { method: 'DELETE' }), 'Assignment deleted');
      break;

    default:
      break;
  }
}

/* ================================================================ wiring */
document.addEventListener('click', async (ev) => {
  const closer = ev.target.closest('[data-close="true"]');
  if (closer) { closeModal(); return; }

  const actionEl = ev.target.closest('[data-action]');
  if (!actionEl) return;
  ev.preventDefault();
  try {
    await handleAction(actionEl.dataset.action, actionEl);
  } catch (err) {
    if (err.status !== 400 && err.status !== 401) toast(err.message, 'err');
  }
});

document.addEventListener('change', async (ev) => {
  const el = ev.target;

  if (el.dataset.change === 'assignment-status') {
    const status = el.value;
    try {
      await api(`/api/assignments/${el.dataset.id}/progress`, { method: 'PATCH', body: { status } });
      toast(`Marked ${STATUS_LABEL[status].toLowerCase()}`);
      await loadCourses();
      await render();
    } catch (err) {
      toast(err.message, 'err');
      await render();
    }
    return;
  }

  if (el.id === 'filter-course') { state.filters.course_id = el.value; await render(); }
  if (el.id === 'filter-status') { state.filters.status = el.value; await render(); }
  if (el.id === 'filter-sort') { state.filters.sort = el.value; await render(); }
});

let searchTimer;
document.addEventListener('input', (ev) => {
  if (ev.target.id !== 'search') return;
  clearTimeout(searchTimer);
  searchTimer = setTimeout(async () => {
    state.filters.q = ev.target.value;
    const caret = ev.target.selectionStart;
    await renderAssignments($('#view'));
    const box = $('#search');
    if (!box) return;
    box.focus();
    box.setSelectionRange(caret, caret);
  }, 260);
});

document.addEventListener('keydown', (ev) => {
  if (ev.key === 'Escape' && !modalRoot().hidden) closeModal();
  const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName);
  if (ev.key === 'n' && !ev.metaKey && !ev.ctrlKey && !typing && modalRoot().hidden && state.user && isTeacher()) {
    if (state.view === 'courses') courseForm();
    else if (state.view === 'syllabus') topicForm();
    else if (state.view === 'assignments') assignmentForm();
  }
});

window.addEventListener('hashchange', render);

/* ------------------------------------------------------------------ boot */
(async function boot() {
  try {
    await api('/api/health');
  } catch {
    $('#view').innerHTML = emptyState('⚠️', 'Cannot reach the server', 'Check that the app is running, then reload.');
    return;
  }

  try {
    state.user = await api('/api/auth/me');
  } catch {
    state.user = null;
  }

  if (!state.user) renderAuth();
  else await render();
})();
