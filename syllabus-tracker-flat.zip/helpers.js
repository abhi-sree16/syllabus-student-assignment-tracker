'use strict';

/** Thrown by validators; the error middleware turns it into a 400 JSON response. */
class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

const bad = (message, details) => {
  throw new HttpError(400, message, details);
};

const isNonEmptyString = (v) => typeof v === 'string' && v.trim().length > 0;
const isInt = (v) => Number.isInteger(Number(v));
const isNumber = (v) => v !== '' && v !== null && v !== undefined && Number.isFinite(Number(v));
const isIsoDate = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v));

/** Parse an :id route param. */
function idParam(req) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) bad('Invalid id');
  return id;
}

/** Take only the known keys that are actually present on the body. */
function pick(body, keys) {
  const out = {};
  if (!body || typeof body !== 'object') return out;
  for (const k of keys) if (body[k] !== undefined) out[k] = body[k];
  return out;
}

/** Build an UPDATE statement from a partial patch, ignoring unknown keys. */
function buildUpdate(table, id, fields) {
  const cols = Object.keys(fields);
  if (cols.length === 0) return null;
  const setSql = cols.map((c) => `${c} = @${c}`).join(', ');
  return { sql: `UPDATE ${table} SET ${setSql} WHERE id = @id`, params: { ...fields, id } };
}

module.exports = { HttpError, bad, isNonEmptyString, isInt, isNumber, isIsoDate, idParam, pick, buildUpdate };
