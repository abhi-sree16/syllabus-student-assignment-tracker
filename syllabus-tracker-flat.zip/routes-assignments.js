'use strict';

const express = require('express');
const { db } = require('./db');
const {
  HttpError, bad, isNonEmptyString, isInt, isNumber, isIsoDate, idParam, pick, buildUpdate,
} = require('./helpers');
const { courseAccess, assignmentAccess, requireOwner, requireStudent } = require('./access');

const router = express.Router();

const TYPES = ['homework', 'quiz', 'lab', 'project', 'exam', 'reading', 'presentation'];
const STUDENT_STATUSES = ['todo', 'in_progress', 'submitted', 'graded', 'late'];
const PRIORITIES = ['low', 'medium', 'high'];
const FIELDS = ['course_id', 'topic_id', 'title', 'description', 'type', 'due_date', 'priority', 'max_marks'];

/** Assignment definition + who is enrolled / who already handed in. */
const STUDENT_SELECT = `
SELECT a.*, c.code AS course_code, c.name AS course_name, c.color AS course_color,
       t.title AS topic_title,
       COALESCE(ap.status, 'todo') AS status, ap.score, ap.notes,
       CAST(julianday(a.due_date) - julianday(date('now')) AS INTEGER) AS days_left
FROM assignments a
JOIN courses c ON c.id = a.course_id
JOIN enrollments e ON e.course_id = c.id AND e.student_id = @sid
LEFT JOIN topics t ON t.id = a.topic_id
LEFT JOIN assignment_progress ap ON ap.assignment_id = a.id AND ap.student_id = @sid`;

const TEACHER_SELECT = `
SELECT a.*, c.code AS course_code, c.name AS course_name, c.color AS course_color,
       t.title AS topic_title,
       (SELECT COUNT(*) FROM assignment_progress ap WHERE ap.assignment_id = a.id AND ap.status = 'submitted') AS submitted_count,
       (SELECT COUNT(*) FROM assignment_progress ap WHERE ap.assignment_id = a.id AND ap.status = 'graded') AS graded_count,
       (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = a.course_id) AS student_count,
       CAST(julianday(a.due_date) - julianday(date('now')) AS INTEGER) AS days_left
FROM assignments a
JOIN courses c ON c.id = a.course_id
LEFT JOIN topics t ON t.id = a.topic_id`;

function validateAssignment(body, { partial = false } = {}) {
  const data = pick(body, FIELDS);
  const errors = {};

  if (!partial || data.course_id !== undefined) {
    if (!isInt(data.course_id)) errors.course_id = 'A valid course is required';
    else data.course_id = Number(data.course_id);
  }
  if (!partial || data.title !== undefined) {
    if (!isNonEmptyString(data.title)) errors.title = 'Assignment title is required';
    else data.title = data.title.trim();
  }
  if (!partial || data.due_date !== undefined) {
    if (!isIsoDate(data.due_date)) errors.due_date = 'Due date must look like YYYY-MM-DD';
  }
  if (data.topic_id !== undefined) {
    if (data.topic_id === null || data.topic_id === '') data.topic_id = null;
    else if (!isInt(data.topic_id)) errors.topic_id = 'Invalid topic';
    else {
      data.topic_id = Number(data.topic_id);
      const topic = db.prepare('SELECT course_id FROM topics WHERE id = ?').get(data.topic_id);
      if (!topic) errors.topic_id = 'That topic does not exist';
      else if (data.course_id !== undefined && topic.course_id !== data.course_id) {
        errors.topic_id = 'That topic belongs to a different course';
      }
    }
  }
  if (data.type !== undefined && !TYPES.includes(data.type)) errors.type = `Type must be one of: ${TYPES.join(', ')}`;
  if (data.priority !== undefined && !PRIORITIES.includes(data.priority)) errors.priority = `Priority must be one of: ${PRIORITIES.join(', ')}`;
  if (data.description !== undefined) data.description = String(data.description).trim();
  if (data.max_marks !== undefined) {
    if (!isNumber(data.max_marks) || Number(data.max_marks) <= 0) errors.max_marks = 'Max marks must be greater than 0';
    else data.max_marks = Number(data.max_marks);
  }

  if (Object.keys(errors).length) bad('Please fix the highlighted fields', errors);
  return data;
}

/** GET /api/assignments — role aware list with filters. */
router.get('/', (req, res) => {
  const teacher = req.user.role === 'teacher';
  const where = [];
  const params = {};
  if (teacher) {
    params.uid = req.user.id;
    where.push('c.owner_id = @uid');
  } else {
    params.sid = req.user.id;
  }

  if (req.query.course_id) {
    if (!isInt(req.query.course_id)) bad('course_id must be a number');
    params.course_id = Number(req.query.course_id);
    where.push('a.course_id = @course_id');
  }

  if (req.query.status && !teacher) {
    const values = String(req.query.status).split(',').filter(Boolean);
    const clauses = values.map((v, i) => {
      if (v === 'open') return "COALESCE(ap.status,'todo') IN ('todo','in_progress','late')";
      if (v === 'overdue') return "COALESCE(ap.status,'todo') IN ('todo','in_progress','late') AND a.due_date < date('now')";
      if (!STUDENT_STATUSES.includes(v)) bad(`status must be one of: ${STUDENT_STATUSES.join(', ')}, open, overdue`);
      params[`status_${i}`] = v;
      return `COALESCE(ap.status,'todo') = @status_${i}`;
    });
    if (clauses.length) where.push(`(${clauses.join(' OR ')})`);
  }

  if (req.query.type) {
    if (!TYPES.includes(req.query.type)) bad(`type must be one of: ${TYPES.join(', ')}`);
    where.push('a.type = @type');
    params.type = req.query.type;
  }
  if (req.query.priority) {
    if (!PRIORITIES.includes(req.query.priority)) bad(`priority must be one of: ${PRIORITIES.join(', ')}`);
    where.push('a.priority = @priority');
    params.priority = req.query.priority;
  }
  if (req.query.q) {
    where.push('(a.title LIKE @q OR a.description LIKE @q OR c.code LIKE @q)');
    params.q = `%${String(req.query.q).trim()}%`;
  }
  if (req.query.due === 'week') {
    where.push("a.due_date BETWEEN date('now') AND date('now', '+7 days')");
  }
  if (req.query.due === 'overdue') {
    where.push("a.due_date < date('now')");
  }

  const sortMap = {
    due: 'a.due_date',
    priority: "CASE a.priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END",
    course: 'c.code',
    created: 'a.created_at',
  };
  const sort = sortMap[req.query.sort] || sortMap.due;
  const order = String(req.query.order).toLowerCase() === 'desc' ? 'DESC' : 'ASC';
  const limit = req.query.limit && isInt(req.query.limit) ? `LIMIT ${Number(req.query.limit)}` : '';

  const sql = `${teacher ? TEACHER_SELECT : STUDENT_SELECT}
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY ${sort} ${order}, a.id ${limit}`;

  res.json(db.prepare(sql).all(params));
});

/** GET /api/assignments/:id */
router.get('/:id', (req, res) => {
  const id = idParam(req);
  const access = assignmentAccess(req.user, id);
  const sql = access.canEdit ? `${TEACHER_SELECT} WHERE a.id = @id` : `${STUDENT_SELECT} WHERE a.id = @id`;
  const row = db.prepare(sql).get({ id, sid: req.user.id, uid: req.user.id });
  res.json(row);
});

/** POST /api/assignments — teacher only. */
router.post('/', (req, res) => {
  const data = validateAssignment(req.body);
  requireOwner(courseAccess(req.user, data.course_id));

  const info = db
    .prepare(`INSERT INTO assignments
              (course_id, topic_id, title, description, type, due_date, priority, max_marks)
              VALUES (@course_id, @topic_id, @title, @description, @type, @due_date, @priority, @max_marks)`)
    .run({
      description: '', type: 'homework', priority: 'medium', max_marks: 100, topic_id: null, ...data,
    });

  const row = db.prepare(`${TEACHER_SELECT} WHERE a.id = @id`).get({ id: info.lastInsertRowid });
  res.status(201).json(row);
});

/** PATCH /api/assignments/:id — teacher edits the definition. */
router.patch('/:id', (req, res) => {
  const id = idParam(req);
  const access = assignmentAccess(req.user, id);
  requireOwner(access);

  const data = { ...validateAssignment(req.body, { partial: true }), updated_at: new Date().toISOString() };
  delete data.course_id;
  const update = buildUpdate('assignments', id, data);
  if (update) db.prepare(update.sql).run(update.params);

  res.json(db.prepare(`${TEACHER_SELECT} WHERE a.id = @id`).get({ id }));
});

/** DELETE /api/assignments/:id — teacher only. */
router.delete('/:id', (req, res) => {
  const id = idParam(req);
  requireOwner(assignmentAccess(req.user, id));
  db.prepare('DELETE FROM assignments WHERE id = ?').run(id);
  res.json({ deleted: id });
});

/** PATCH /api/assignments/:id/progress — student's own status / notes. */
router.patch('/:id/progress', (req, res) => {
  const id = idParam(req);
  const access = assignmentAccess(req.user, id);
  if (req.user.role !== 'student') throw new HttpError(403, 'Teachers grade work instead of submitting it');
  requireStudent(access);

  const { status, notes } = req.body || {};
  const errors = {};
  const allowed = ['todo', 'in_progress', 'submitted'];
  if (status !== undefined && !allowed.includes(status)) errors.status = `Status must be one of: ${allowed.join(', ')}`;
  if (notes !== undefined && typeof notes !== 'string') errors.notes = 'Notes must be text';
  if (Object.keys(errors).length) bad('Please fix the highlighted fields', errors);

  const existing = db
    .prepare('SELECT * FROM assignment_progress WHERE assignment_id = ? AND student_id = ?')
    .get(id, req.user.id);

  const nextStatus = status ?? existing?.status ?? 'todo';
  const nextNotes = notes !== undefined ? String(notes).trim() : existing?.notes ?? '';

  db.prepare(`
    INSERT INTO assignment_progress (assignment_id, student_id, status, score, notes, updated_at)
    VALUES (@assignment_id, @student_id, @status, @score, @notes, datetime('now'))
    ON CONFLICT (assignment_id, student_id) DO UPDATE SET
      status = excluded.status, notes = excluded.notes, updated_at = excluded.updated_at`)
    .run({
      assignment_id: id, student_id: req.user.id, status: nextStatus,
      score: existing?.score ?? null, notes: nextNotes,
    });

  res.json(db.prepare(`${STUDENT_SELECT} WHERE a.id = @id`).get({ id, sid: req.user.id }));
});

/** GET /api/assignments/:id/submissions — teacher sees every student. */
router.get('/:id/submissions', (req, res) => {
  const id = idParam(req);
  const access = assignmentAccess(req.user, id);
  requireOwner(access);

  const students = db.prepare(`
    SELECT u.id, u.name, u.email,
           COALESCE(ap.status, 'todo') AS status, ap.score, COALESCE(ap.notes, '') AS notes
    FROM enrollments e
    JOIN users u ON u.id = e.student_id
    LEFT JOIN assignment_progress ap ON ap.assignment_id = @aid AND ap.student_id = u.id
    WHERE e.course_id = @cid
    ORDER BY u.name`).all({ aid: id, cid: access.assignment.course_id });

  const course = db.prepare('SELECT id, code, name FROM courses WHERE id = ?').get(access.assignment.course_id);
  res.json({ assignment: { ...access.assignment, course_code: course?.code, course_name: course?.name }, students });
});

/** PATCH /api/assignments/:id/grade — teacher records a score for one student. */
router.patch('/:id/grade', (req, res) => {
  const id = idParam(req);
  const access = assignmentAccess(req.user, id);
  requireOwner(access);

  const studentId = Number(req.body?.student_id);
  const score = req.body?.score;
  const errors = {};

  if (!Number.isInteger(studentId) || studentId <= 0) errors.student_id = 'Choose a student';
  else {
    const enrolled = db
      .prepare('SELECT 1 FROM enrollments WHERE course_id = ? AND student_id = ?')
      .get(access.assignment.course_id, studentId);
    if (!enrolled) errors.student_id = 'That student is not enrolled in this course';
  }
  if (!isNumber(score) || Number(score) < 0) errors.score = 'Score must be zero or more';
  else if (Number(score) > access.assignment.max_marks) {
    errors.score = `Score cannot exceed ${access.assignment.max_marks}`;
  }
  if (Object.keys(errors).length) bad('Please fix the highlighted fields', errors);

  db.prepare(`
    INSERT INTO assignment_progress (assignment_id, student_id, status, score, notes, updated_at)
    VALUES (@aid, @sid, 'graded', @score, '', datetime('now'))
    ON CONFLICT (assignment_id, student_id) DO UPDATE SET
      status = 'graded', score = excluded.score, updated_at = excluded.updated_at`)
    .run({ aid: id, sid: studentId, score: Number(score) });

  res.json(db
    .prepare('SELECT * FROM assignment_progress WHERE assignment_id = ? AND student_id = ?')
    .get(id, studentId));
});

module.exports = router;
module.exports.TYPES = TYPES;
module.exports.PRIORITIES = PRIORITIES;
