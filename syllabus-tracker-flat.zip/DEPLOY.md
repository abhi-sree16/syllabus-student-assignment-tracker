# 🚀 Deploying to a live URL

The app is a single Node process serving both the API and the front-end, backed by a SQLite file.
Any host that runs Node works. Render is the quickest free option.

---

## Option 1 — Render (blueprint, ~3 minutes)

1. Push the repo to GitHub (see `PUSH-TO-GITHUB-MOBILE.md` if you're doing it from a phone).
2. Go to **dashboard.render.com → New → Blueprint**.
3. Pick your repository. Render reads `render.yaml` and shows the plan.
4. Click **Apply**. The first build takes ~2 minutes.
5. Open the URL Render gives you (e.g. `https://syllabus-tracker-xxxx.onrender.com`).

Sign in with a demo account — the database seeds itself on first boot:

| Role | Email | Password |
| --- | --- | --- |
| Teacher | `priya@demo.edu` | `demo1234` |
| Student | `abhi@demo.edu` | `demo1234` |

### ⚠️ Free-tier data loss

Render's free plan has **no persistent disk**. The SQLite file lives on ephemeral storage, so
accounts and progress reset whenever the service redeploys, restarts or wakes from sleep.
That is fine for a demo — the seed data comes back — but not for real coursework.

To keep data, upgrade the instance and uncomment the disk block in `render.yaml`:

```yaml
    disks:
      - name: tracker-data
        mountPath: /var/data
        sizeGB: 1
    envVars:
      - key: DB_PATH
        value: /var/data/tracker.db
```

`DB_PATH` is the only setting that decides where SQLite writes, so any mounted volume works.

---

## Option 2 — Railway

1. **railway.app → New Project → Deploy from GitHub repo**.
2. Railway detects Node automatically (`npm install`, `npm start`).
3. Add a **Volume** mounted at `/data`, then set the variable
   `DB_PATH=/var/data/tracker.db`.
4. **Settings → Networking → Generate domain**.

## Option 3 — Fly.io / any Docker host

A `Dockerfile` is included:

```bash
fly launch --no-deploy          # accept the generated config
fly volumes create tracker_data --size 1
# in fly.toml: [mounts] source = "tracker_data"  destination = "/data"
fly deploy
```

Cloud Run, Koyeb and Dokku work the same way — build the image, mount a volume at `/data`,
set `DB_PATH=/data/tracker.db`.

---

## Environment variables

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `3000` | Port to listen on (hosts usually inject this) |
| `HOST` | `0.0.0.0` | Bind address |
| `DB_PATH` | `./data/tracker.db` | Where the SQLite file lives — point at a mounted disk |
| `NODE_ENV` | — | Set to `production` on a host |

Sessions are httpOnly cookies with `SameSite=Lax`, marked `Secure` automatically when the request
arrives over HTTPS (`app.set('trust proxy', 1)` makes this work behind any proxy).

## Health check

`GET /api/health` returns JSON without needing a session — point the platform's health check at it:

```json
{ "ok": true, "schema": 2, "database": "tracker.db", "users": 4, "courses": 4, "uptime_s": 12 }
```

## After you deploy

- Change the demo passwords, or delete the demo users, before sharing the URL publicly.
- The app is multi-user already: teachers sign up, create a course, and share the 6-character
  join code with students.
- SQLite handles a class-sized workload comfortably. If you ever need many concurrent writers,
  the data layer is isolated in `server/db.js` and the route modules — swapping in Postgres means
  rewriting those queries, nothing else.
