'use strict';

const express = require('express');
const { db, generateJoinCode } = require('./db');
const { HttpError, bad, isNonEmptyString, isInt, idParam, pick, buildUpdate } = require('./helpers');
const { courseAccess, requireOwner } = require('./access');

const router = express.Router();
const FIELDS = ['code', 'name', 'instructor', 'semester', 'credits', 'color'];

/* ------------------------------------------------------------------- SQL */

const STUDENT_COURSE_SELECT = `
SELECT c.*, u.name AS teacher_name,
  (SELECT COUNT(*) FROM topics t WHERE t.course_id = c.id) AS topic_count,
  (SELECT COUNT(*) FROM topics t JOIN topic_progress p
      ON p.topic_id = t.id AND p.student_id = @sid
      WHERE t.course_id = c.id AND p.status = 'completed') AS topics_completed,
  (SELECT COUNT(*) FROM topics t JOIN topic_progress p
      ON p.topic_id = t.id AND p.student_id = @sid
      WHERE t.course_id = c.id AND p.status = 'in_progress') AS topics_in_progress,
  (SELECT COALESCE(SUM(t.est_hours), 0) FROM topics t WHERE t.course_id = c.id) AS syllabus_hours,
  (SELECT COUNT(*) FROM assignments a LEFT JOIN assignment_progress ap
      ON ap.assignment_id = a.id AND ap.student_id = @sid
      WHERE a.course_id = c.id
        AND COALESCE(ap.status, 'todo') IN ('todo','in_progress','late')) AS open_assignments,
  (SELECT COUNT(*) FROM assignments a LEFT JOIN assignment_progress ap
      ON ap.assignment_id = a.id AND ap.student_id = @sid
      WHERE a.course_id = c.id
        AND COALESCE(ap.status, 'todo') IN ('todo','in_progress','late')
        AND a.due_date < date('now')) AS overdue_assignments
FROM courses c
JOIN enrollments e ON e.course_id = c.id AND e.student_id = @sid
JOIN users u ON u.id = c.owner_id`;

const TEACHER_COURSE_SELECT = `
SELECT c.*,
  (SELECT COUNT(*) FROM topics t WHERE t.course_id = c.id) AS topic_count,
  (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id) AS student_count,
  (SELECT COUNT(*) FROM assignments a WHERE a.course_id = c.id) AS assignment_count,
  (SELECT COUNT(*) FROM topic_progress p JOIN topics t ON t.id = p.topic_id
      WHERE t.course_id = c.id AND p.status = 'completed') AS completed_marks,
  (SELECT COUNT(*) FROM assignment_progress ap JOIN assignments a ON a.id = ap.assignment_id
      WHERE a.course_id = c.id AND ap.status = 'submitted') AS to_grade
FROM courses c WHERE c.owner_id = @uid`;

const shapeCourse = (row, role) => {
  if (role === 'teacher') {
    const possible = (row.topic_count || 0) * (row.student_count || 0);
    return {
      ...row,
      // class-wide coverage: completed marks across all enrolled students
      progress: possible ? Math.round(((row.completed_marks || 0) / possible) * 100) : 0,
      open_assignments: row.assignment_count || 0,
      overdue_assignments: 0,
    };
  }
  return {
    ...row,
    progress: row.topic_count ? Math.round((row.topics_completed / row.topic_count) * 100) : 0,
  };
};

function validateCourse(body, { partial = false } = {}) {
  const data = pick(body, FIELDS);
  const errors = {};

  if (!partial || data.code !== undefined) {
    if (!isNonEmptyString(data.code)) errors.code = 'Course code is required';
    else data.code = data.code.trim().toUpperCase();
  }
  if (!partial || data.name !== undefined) {
    if (!isNonEmptyString(data.name)) errors.name = 'Course name is required';
    else data.name = data.name.trim();
  }
  if (data.instructor !== undefined) data.instructor = String(data.instructor).trim();
  if (data.semester !== undefined) data.semester = String(data.semester).trim();
  if (data.credits !== undefined) {
    if (!isInt(data.credits) || Number(data.credits) < 0) errors.credits = 'Credits must be a non-negative number';
    else data.credits = Number(data.credits);
  }
  if (data.color !== undefined && !/^#[0-9a-fA-F]{6}$/.test(String(data.color))) {
    errors.color = 'Colour must be a hex value like #6366f1';
  }

  if (Object.keys(errors).length) bad('Please fix the highlighted fields', errors);
  return data;
}

/* ---------------------------------------------------------------- routes */

/** GET /api/courses — a teacher's own courses, or a student's enrolled ones. */
router.get('/', (req, res) => {
  const rows = req.user.role === 'teacher'
    ? db.prepare(TEACHER_COURSE_SELECT).all({ uid: req.user.id })
    : db.prepare(`${STUDENT_COURSE_SELECT} ORDER BY c.code`).all({ sid: req.user.id });
  res.json(rows.map((r) => shapeCourse(r, req.user.role)));
});

/** POST /api/courses/join — student enrols with a join code. */
router.post('/join', (req, res) => {
  if (req.user.role !== 'student') bad('Only students join courses with a code');
  const code = String(req.body?.code || '').trim().toUpperCase();
  if (!code) bad('Enter the join code your teacher gave you', { code: 'Join code is required' });

  const course = db.prepare('SELECT * FROM courses WHERE join_code = ?').get(code);
  if (!course) throw new HttpError(404, 'No course matches that join code', { code: 'Check the code and try again' });

  const already = db
    .prepare('SELECT 1 FROM enrollments WHERE course_id = ? AND student_id = ?')
    .get(course.id, req.user.id);
  if (already) throw new HttpError(409, 'You are already enrolled in this course');

  db.prepare('INSERT INTO enrollments (course_id, student_id) VALUES (?,?)').run(course.id, req.user.id);
  const row = db.prepare(`${STUDENT_COURSE_SELECT} WHERE c.id = @cid`).get({ sid: req.user.id, cid: course.id });
  res.status(201).json(shapeCourse(row, 'student'));
});

/** GET /api/courses/:id — course detail with topics and assignments. */
router.get('/:id', (req, res) => {
  const id = idParam(req);
  const { course, canEdit } = courseAccess(req.user, id);
  const sid = req.user.id;

  const topics = canEdit
    ? db.prepare(`
        SELECT t.*,
          (SELECT COUNT(*) FROM topic_progress p WHERE p.topic_id = t.id AND p.status = 'completed') AS class_completed,
          (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = t.course_id) AS student_count
        FROM topics t WHERE t.course_id = ? ORDER BY t.position, t.id`).all(id)
    : db.prepare(`
        SELECT t.*, COALESCE(p.status, 'not_started') AS status, COALESCE(p.confidence, 0) AS confidence,
               p.completed_at,
          (SELECT COUNT(*) FROM topic_progress tp WHERE tp.topic_id = t.id AND tp.status = 'completed') AS class_completed,
          (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = t.course_id) AS student_count
        FROM topics t
        LEFT JOIN topic_progress p ON p.topic_id = t.id AND p.student_id = ?
        WHERE t.course_id = ? ORDER BY t.position, t.id`).all(sid, id);

  const assignments = canEdit
    ? db.prepare(`
        SELECT a.*,
          (SELECT COUNT(*) FROM assignment_progress ap WHERE ap.assignment_id = a.id AND ap.status = 'submitted') AS submitted_count,
          (SELECT COUNT(*) FROM assignment_progress ap WHERE ap.assignment_id = a.id AND ap.status = 'graded') AS graded_count,
          (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = a.course_id) AS student_count
        FROM assignments a WHERE a.course_id = ? ORDER BY a.due_date, a.id`).all(id)
    : db.prepare(`
        SELECT a.*, COALESCE(ap.status, 'todo') AS status, ap.score, ap.notes
        FROM assignments a
        LEFT JOIN assignment_progress ap ON ap.assignment_id = a.id AND ap.student_id = ?
        WHERE a.course_id = ? ORDER BY a.due_date, a.id`).all(sid, id);

  const rollup = canEdit
    ? db.prepare(TEACHER_COURSE_SELECT.replace('WHERE c.owner_id = @uid', 'WHERE c.id = @cid'))
        .get({ cid: id })
    : db.prepare(`${STUDENT_COURSE_SELECT} WHERE c.id = @cid`).get({ sid, cid: id });

  res.json({ ...shapeCourse(rollup, req.user.role), topics, assignments, role: req.user.role });
});

/** POST /api/courses — teacher creates a course (join code generated). */
router.post('/', (req, res) => {
  if (req.user.role !== 'teacher') throw new HttpError(403, 'Only teachers create courses');
  const data = validateCourse(req.body);

  const clash = db
    .prepare('SELECT id FROM courses WHERE owner_id = ? AND code = ?')
    .get(req.user.id, data.code);
  if (clash) throw new HttpError(409, `You already have a course called ${data.code}`);

  const info = db
    .prepare(`INSERT INTO courses (owner_id, code, name, instructor, semester, credits, color, join_code)
              VALUES (@owner_id, @code, @name, @instructor, @semester, @credits, @color, @join_code)`)
    .run({
      owner_id: req.user.id, instructor: '', semester: '', credits: 3, color: '#6366f1',
      ...data, join_code: generateJoinCode(),
    });

  const row = db.prepare(TEACHER_COURSE_SELECT.replace('WHERE c.owner_id = @uid', 'WHERE c.id = @cid'))
    .get({ cid: info.lastInsertRowid });
  res.status(201).json(shapeCourse(row, 'teacher'));
});

/** PATCH /api/courses/:id — owner only. */
router.patch('/:id', (req, res) => {
  const id = idParam(req);
  const access = requireOwner(courseAccess(req.user, id));
  const data = validateCourse(req.body, { partial: true });

  if (data.code && data.code !== access.course.code) {
    const clash = db
      .prepare('SELECT id FROM courses WHERE owner_id = ? AND code = ? AND id <> ?')
      .get(req.user.id, data.code, id);
    if (clash) throw new HttpError(409, `You already have a course called ${data.code}`);
  }

  const update = buildUpdate('courses', id, data);
  if (update) db.prepare(update.sql).run(update.params);

  const row = db.prepare(TEACHER_COURSE_SELECT.replace('WHERE c.owner_id = @uid', 'WHERE c.id = @cid'))
    .get({ cid: id });
  res.json(shapeCourse(row, 'teacher'));
});

/** DELETE /api/courses/:id — owner only, cascades. */
router.delete('/:id', (req, res) => {
  const id = idParam(req);
  requireOwner(courseAccess(req.user, id));
  db.prepare('DELETE FROM courses WHERE id = ?').run(id);
  res.json({ deleted: id });
});

/** GET /api/courses/:id/roster — teacher sees each student's progress. */
router.get('/:id/roster', (req, res) => {
  const id = idParam(req);
  const { course } = requireOwner(courseAccess(req.user, id));

  const students = db.prepare(`
    SELECT u.id, u.name, u.email,
      (SELECT COUNT(*) FROM topics t WHERE t.course_id = @cid) AS topic_count,
      (SELECT COUNT(*) FROM topics t JOIN topic_progress p
         ON p.topic_id = t.id AND p.student_id = u.id
         WHERE t.course_id = @cid AND p.status = 'completed') AS topics_completed,
      (SELECT COUNT(*) FROM assignments a LEFT JOIN assignment_progress ap
         ON ap.assignment_id = a.id AND ap.student_id = u.id
         WHERE a.course_id = @cid AND COALESCE(ap.status,'todo') IN ('todo','in_progress','late')) AS open_assignments,
      (SELECT COUNT(*) FROM assignments a LEFT JOIN assignment_progress ap
         ON ap.assignment_id = a.id AND ap.student_id = u.id
         WHERE a.course_id = @cid AND ap.status = 'submitted') AS submitted_count,
      (SELECT ROUND(AVG(ap.score * 100.0 / a.max_marks), 1)
         FROM assignment_progress ap JOIN assignments a ON a.id = ap.assignment_id
         WHERE a.course_id = @cid AND ap.student_id = u.id AND ap.score IS NOT NULL) AS average_percent
    FROM enrollments e JOIN users u ON u.id = e.student_id
    WHERE e.course_id = @cid
    ORDER BY u.name`).all({ cid: id });

  res.json({
    course: { id, code: course.code, name: course.name, join_code: course.join_code },
    students: students.map((s) => ({
      ...s,
      progress: s.topic_count ? Math.round((s.topics_completed / s.topic_count) * 100) : 0,
    })),
  });
});

module.exports = router;
