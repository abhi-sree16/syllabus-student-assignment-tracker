'use strict';

const { db } = require('./db');
const { HttpError } = require('./helpers');

/** The course plus what this user may do with it, or a 403/404. */
function courseAccess(user, courseId) {
  const course = db.prepare('SELECT * FROM courses WHERE id = ?').get(courseId);
  if (!course) throw new HttpError(404, 'Course not found');

  const isOwner = course.owner_id === user.id;
  if (user.role === 'teacher') {
    if (!isOwner) throw new HttpError(403, 'That course belongs to another teacher');
    return { course, isOwner: true, isEnrolled: false, canEdit: true };
  }

  const enrolled = !!db
    .prepare('SELECT 1 FROM enrollments WHERE course_id = ? AND student_id = ?')
    .get(courseId, user.id);
  if (!enrolled) throw new HttpError(403, 'Join this course first using its join code');
  return { course, isOwner: false, isEnrolled: true, canEdit: false };
}

/** Course behind a topic, with access check. */
function topicAccess(user, topicId) {
  const topic = db.prepare('SELECT * FROM topics WHERE id = ?').get(topicId);
  if (!topic) throw new HttpError(404, 'Topic not found');
  const access = courseAccess(user, topic.course_id);
  return { topic, ...access };
}

/** Course behind an assignment, with access check. */
function assignmentAccess(user, assignmentId) {
  const assignment = db.prepare('SELECT * FROM assignments WHERE id = ?').get(assignmentId);
  if (!assignment) throw new HttpError(404, 'Assignment not found');
  const access = courseAccess(user, assignment.course_id);
  return { assignment, ...access };
}

/** Only the owning teacher may change course content. */
function requireOwner(access, what = 'course') {
  if (!access.canEdit) throw new HttpError(403, `Only the teacher who owns this ${what} can change it`);
  return access;
}

/** Only an enrolled student's own progress may be written. */
function requireStudent(access) {
  if (!access.isEnrolled) throw new HttpError(403, 'Only enrolled students have progress to update');
  return access;
}

module.exports = { courseAccess, topicAccess, assignmentAccess, requireOwner, requireStudent };
