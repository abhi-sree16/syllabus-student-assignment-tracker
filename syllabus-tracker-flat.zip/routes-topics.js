'use strict';

const express = require('express');
const { db } = require('./db');
const {
  HttpError, bad, isNonEmptyString, isInt, isNumber, idParam, pick, buildUpdate,
} = require('./helpers');
const { courseAccess, topicAccess, requireOwner, requireStudent } = require('./access');

const router = express.Router();

const STATUSES = ['not_started', 'in_progress', 'completed'];
const FIELDS = ['course_id', 'unit', 'title', 'description', 'est_hours', 'position'];

function validateTopic(body, { partial = false } = {}) {
  const data = pick(body, FIELDS);
  const errors = {};

  if (!partial || data.course_id !== undefined) {
    if (!isInt(data.course_id)) errors.course_id = 'A valid course is required';
    else data.course_id = Number(data.course_id);
  }
  if (!partial || data.title !== undefined) {
    if (!isNonEmptyString(data.title)) errors.title = 'Topic title is required';
    else data.title = data.title.trim();
  }
  if (data.unit !== undefined) data.unit = String(data.unit).trim() || 'Unit 1';
  if (data.description !== undefined) data.description = String(data.description).trim();
  if (data.est_hours !== undefined) {
    if (!isNumber(data.est_hours) || Number(data.est_hours) < 0) errors.est_hours = 'Estimated hours must be a positive number';
    else data.est_hours = Number(data.est_hours);
  }
  if (data.position !== undefined) {
    if (!isInt(data.position)) errors.position = 'Position must be a whole number';
    else data.position = Number(data.position);
  }

  if (Object.keys(errors).length) bad('Please fix the highlighted fields', errors);
  return data;
}

/** GET /api/topics?course_id= — topics with the caller's progress. */
router.get('/', (req, res) => {
  const teacher = req.user.role === 'teacher';
  const where = [];
  // teachers have no personal progress rows; -1 never matches
  const params = { sid: teacher ? -1 : req.user.id };
  if (teacher) params.uid = req.user.id;

  if (req.query.course_id) {
    if (!isInt(req.query.course_id)) bad('course_id must be a number');
    const id = Number(req.query.course_id);
    courseAccess(req.user, id); // throws if the caller may not see it
    where.push('t.course_id = @course_id');
    params.course_id = id;
  }

  const scope = teacher
    ? 'JOIN courses c ON c.id = t.course_id AND c.owner_id = @uid'
    : 'JOIN enrollments e ON e.course_id = t.course_id AND e.student_id = @sid';

  const sql = `
    SELECT t.*, COALESCE(p.status, 'not_started') AS status, COALESCE(p.confidence, 0) AS confidence,
           p.completed_at
    FROM topics t
    ${scope}
    LEFT JOIN topic_progress p ON p.topic_id = t.id AND p.student_id = @sid
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY t.course_id, t.position, t.id`;

  res.json(db.prepare(sql).all(params));
});

/** POST /api/topics — teacher adds a syllabus topic to their course. */
router.post('/', (req, res) => {
  const data = validateTopic(req.body);
  requireOwner(courseAccess(req.user, data.course_id));

  const position = data.position ?? (db
    .prepare('SELECT COALESCE(MAX(position), -1) + 1 AS next FROM topics WHERE course_id = ?')
    .get(data.course_id).next);

  const info = db
    .prepare(`INSERT INTO topics (course_id, unit, title, description, est_hours, position)
              VALUES (@course_id, @unit, @title, @description, @est_hours, @position)`)
    .run({
      description: '', unit: 'Unit 1', est_hours: 1, ...data, position,
    });

  res.status(201).json(db.prepare('SELECT * FROM topics WHERE id = ?').get(info.lastInsertRowid));
});

/** PATCH /api/topics/:id — teacher edits the definition. */
router.patch('/:id', (req, res) => {
  const id = idParam(req);
  const access = topicAccess(req.user, id);
  requireOwner(access);

  const data = validateTopic(req.body, { partial: true });
  delete data.course_id; // moving a topic between courses is not supported

  const update = buildUpdate('topics', id, data);
  if (update) db.prepare(update.sql).run(update.params);
  res.json(db.prepare('SELECT * FROM topics WHERE id = ?').get(access.topic.id));
});

/** DELETE /api/topics/:id — teacher only. */
router.delete('/:id', (req, res) => {
  const id = idParam(req);
  const access = topicAccess(req.user, id);
  requireOwner(access);
  db.prepare('DELETE FROM topics WHERE id = ?').run(id);
  res.json({ deleted: id });
});

/** PATCH /api/topics/:id/progress — a student's own coverage of this topic. */
router.patch('/:id/progress', (req, res) => {
  const id = idParam(req);
  const access = topicAccess(req.user, id);

  if (req.user.role !== 'student') throw new HttpError(403, 'Teachers do not have personal progress');
  requireStudent(access);

  const { status, confidence } = req.body || {};
  const errors = {};
  if (status !== undefined && !STATUSES.includes(status)) errors.status = `Status must be one of: ${STATUSES.join(', ')}`;
  if (confidence !== undefined && (!isInt(confidence) || Number(confidence) < 0 || Number(confidence) > 5)) {
    errors.confidence = 'Confidence must be between 0 and 5';
  }
  if (Object.keys(errors).length) bad('Please fix the highlighted fields', errors);

  const existing = db
    .prepare('SELECT * FROM topic_progress WHERE topic_id = ? AND student_id = ?')
    .get(id, req.user.id);

  const nextStatus = status ?? existing?.status ?? 'not_started';
  const nextConfidence = confidence !== undefined ? Number(confidence) : existing?.confidence ?? 0;
  let completedAt = existing?.completed_at ?? null;
  if (nextStatus === 'completed' && existing?.status !== 'completed') completedAt = new Date().toISOString();
  if (nextStatus !== 'completed') completedAt = null;

  db.prepare(`
    INSERT INTO topic_progress (topic_id, student_id, status, confidence, completed_at, updated_at)
    VALUES (@topic_id, @student_id, @status, @confidence, @completed_at, datetime('now'))
    ON CONFLICT (topic_id, student_id) DO UPDATE SET
      status = excluded.status, confidence = excluded.confidence,
      completed_at = excluded.completed_at, updated_at = excluded.updated_at`)
    .run({
      topic_id: id, student_id: req.user.id, status: nextStatus,
      confidence: nextConfidence, completed_at: completedAt,
    });

  res.json(db
    .prepare('SELECT * FROM topic_progress WHERE topic_id = ? AND student_id = ?')
    .get(id, req.user.id));
});

module.exports = router;
module.exports.STATUSES = STATUSES;
